/**
 * Outil "Mouvement" — pose deux marqueurs autofermants dans le texte,
 * <crochetouvert/> et <crochetferme/>, appariés par un attribut `pair`
 * commun (ordre d'apparition dans le DOM). La mécanique générique de
 * prise en main (souris) vient de ../lib/grab.js, celle de placement
 * tap-à-tap (tactile) de ../lib/tapPlace.js, et celle du panneau du bas
 * de ../lib/panelList.js ; ce fichier ne porte que ce qui est propre à
 * Mouvement (forme des marqueurs, appariement, couleurs, overlay).
 */

import { useEffect, useRef, useState } from "react";
import { startGrab, snapBetweenWords, snapBetweenWordsTolerant, makeId } from "../lib/grab";
import {
  isTouchDevice,
  isTap,
  trackTap,
  markTapSource,
  toggleArm,
  subscribeArmed,
  wireTapCanvas,
  wireTapTrash,
} from "../lib/tapPlace";
import { usePanelList } from "../lib/panelList";
import { allMarkers, getPairs, assignLanes } from "../lib/overlayGeometry";
import ExplicationCard from "../ExplicationCard";
import "./mouvement.css";

/* ---------- couleur d'une paire ---------- */

// Angle doré : répartit les teintes uniformément sur le cercle, deux
// paires ne se retrouvent jamais voisines même très éloignées dans le
// temps de création (contrairement à un tirage aléatoire retenté).
const GOLDEN_ANGLE = 137.508;
let hueSeed = Math.random() * 360;
const nextHue = () => Math.round((hueSeed = (hueSeed + GOLDEN_ANGLE) % 360));

const markerColor = (hue) => ({ color: `hsl(${hue}, 62%, 30%)`, background: `hsl(${hue}, 62%, 90%)` });
const lineColor = (hue) => `hsl(${hue}, 62%, 38%)`;

function applyPairColor(el, hue) {
  if (!Number.isFinite(hue)) return;
  const { color, background } = markerColor(hue);
  el.style.setProperty("--marker-color", color);
  el.style.setProperty("--marker-bg", background);
}

/* ---------- création et appariement d'un marqueur ---------- */

function createMarker(kind) {
  const el = document.createElement(kind === "open" ? "crochetouvert" : "crochetferme");
  el.id = makeId(kind === "open" ? "co" : "cf");
  el.textContent = kind === "open" ? "[" : "]";
  el.className = "explication-mouvement-marker";
  return el;
}

function partnerOf(el, container) {
  const pid = el.getAttribute("pair");
  if (!pid) return null;
  return allMarkers(container).find((m) => m !== el && m.getAttribute("pair") === pid) || null;
}

function confirmPair(a, b, bump) {
  const pairId = makeId("pair");
  const hue = nextHue();
  [a, b].forEach((el) => {
    el.setAttribute("pair", pairId);
    el.setAttribute("hue", hue);
    applyPairColor(el, hue);
  });
  bump && bump();
}

// Un crochet dont le partenaire disparaît redevient "solo" (couleur par
// défaut), sinon il ne pourrait plus jamais se réapparier.
function releasePartner(el, container) {
  const partner = partnerOf(el, container);
  if (!partner) return;
  partner.removeAttribute("pair");
  partner.removeAttribute("hue");
  partner.style.removeProperty("--marker-color");
  partner.style.removeProperty("--marker-bg");
}

// Tente d'apparier un marqueur qu'on vient de poser avec un candidat
// libre du bon type et du bon côté. S'il y en a plusieurs, surbrillance
// des candidats et on attend un clic de confirmation (ou Échap).
function pairAfterInsert(marker, container, bump) {
  const isOpen = marker.tagName.toLowerCase() === "crochetouvert";
  const wantedTag = isOpen ? "crochetferme" : "crochetouvert";
  const all = allMarkers(container);
  const idx = all.indexOf(marker);

  const candidates = all.filter(
    (el, i) => el.tagName.toLowerCase() === wantedTag && !el.hasAttribute("pair") && (isOpen ? i > idx : i < idx)
  );

  if (candidates.length === 0) return;
  if (candidates.length === 1) return confirmPair(marker, candidates[0], bump);

  candidates.forEach((el) => el.classList.add("explication-mouvement-marker--candidate"));
  function cleanup() {
    candidates.forEach((el) => el.classList.remove("explication-mouvement-marker--candidate"));
    container.removeEventListener("click", onClick, true);
    window.removeEventListener("keydown", onKey);
  }
  function onClick(e) {
    const target = candidates.find((c) => c === e.target || c.contains(e.target));
    if (!target) return;
    cleanup();
    confirmPair(marker, target, bump);
  }
  function onKey(e) {
    if (e.key === "Escape") cleanup();
  }
  container.addEventListener("click", onClick, true);
  window.addEventListener("keydown", onKey);
}

/* ---------- placement "tap-à-tap" (mobile) ----------
 * Glisser un crochet au doigt est peu précis (le doigt cache la cible
 * pendant tout le transport). Sur tactile, on remplace donc le drag par
 * deux taps : le premier ARME un crochet — neuf depuis la barre d'outils,
 * ou déjà posé pour le redéplacer — le second, dans le texte, le dépose
 * à l'endroit visé. Retaper sur l'objet armé (chip ou crochet) annule ;
 * taper sur la poubelle supprime un crochet déjà posé en cours de
 * redéplacement.
 *
 * La mécanique elle-même (état armé, pub-sub pour le chip React, tap
 * ailleurs qui annule, tap sur la poubelle) est générique et vit dans
 * ../lib/tapPlace.js — ce fichier ne fournit que ce qui est propre à
 * Mouvement : comment poser/redéplacer un crochet (`place`), comment le
 * supprimer (`onTrash`), et sa classe CSS "armé" (`onArmChange`).
 */

function attachHandlers(el, container, helpers) {
  // Marque le crochet comme source d'armement : sans ça, le tap qui
  // l'arme (ou qui annule un armement en le retapant) serait lui-même
  // intercepté par le "tap ailleurs annule" global de tapPlace.js. Voir
  // markTapSource pour le détail.
  markTapSource(el);

  // Lâché sur la poubelle : le mouvement entier disparaît (les 2 crochets).
  function removePair() {
    partnerOf(el, container)?.remove();
    el.remove();
    helpers.bump();
  }

  el.addEventListener("pointerdown", (e) => {
    if (isTouchDevice()) return; // le tactile arme/désarme au relâchement (pointerup, voir trackTap ci-dessous), pas de drag
    e.preventDefault();
    e.stopPropagation();
    const ghost = el.cloneNode(true);
    ghost.classList.add("explication-mouvement-marker--ghost");

    startGrab({
      container,
      resolve: snapBetweenWords,
      ghostContent: ghost,
      sourceEl: el,
      event: e,
      onDrop({ range }) {
        el.remove();
        range.insertNode(el);
        helpers.bump();
      },
      onDelete: removePair,
    });
  });

  // Tap-à-tap : un premier tap sur un crochet déjà posé l'arme pour un
  // redéplacement ; retaper dessus annule (voir toggleArm).
  trackTap(el, (e) => {
    if (!isTouchDevice()) return;
    e.preventDefault();
    e.stopPropagation();

    toggleArm({
      toolId: "mouvement",
      key: el,
      el,
      container,
      resolve: snapBetweenWordsTolerant,
      onArmChange(isArmed) {
        el.classList.toggle("explication-mouvement-marker--armed", isArmed);
      },
      place(range) {
        el.remove();
        range.insertNode(el);
        helpers.bump();
      },
      onTrash() {
        removePair();
      },
    });
  });
}

/* ---------- barre d'outils ---------- */

function ToolbarWidget({ startDrag, containerRef, helpers }) {
  // Reflète en state React lequel des deux chips (s'il y en a un) est
  // actuellement armé — synchronisé via subscribeArmed, d'où que
  // l'armement change (y compris depuis le texte : réarmer un crochet
  // déjà posé désarme le chip). null si aucun, sinon "open" ou "close".
  const [armedKind, setArmedKind] = useState(null);

  useEffect(
    () =>
      subscribeArmed((a) => {
        setArmedKind(a && a.toolId === "mouvement" && a.el == null ? a.key : null);
      }),
    []
  );

  const tapStart = useRef(null);

  // Tap-à-tap : un tap sur le chip arme un crochet neuf (posé au tap
  // suivant dans le texte, voir wireTapCanvas dans lib/tapPlace.js) plutôt
  // que de démarrer un drag — inutilisable au doigt, qui cache la cible.
  // Retaper le même chip annule (toggleArm).
  function handlePointerDown(kind) {
    return (e) => {
      if (isTouchDevice()) {
        tapStart.current = { x: e.clientX, y: e.clientY };
        return;
      }
      startDrag({ kind })(e);
    };
  }

  function handlePointerUp(kind) {
    return (e) => {
      if (!isTouchDevice()) return;
      const start = tapStart.current;
      tapStart.current = null;
      if (!isTap(start, e)) return;
      e.preventDefault();
      const container = containerRef?.current;
      if (!container || !helpers) return;

      toggleArm({
        toolId: "mouvement",
        key: kind,
        container,
        resolve: snapBetweenWordsTolerant,
        place(range) {
          const newEl = createMarker(kind);
          range.insertNode(newEl);
          attachHandlers(newEl, container, helpers);
          pairAfterInsert(newEl, container, helpers.bump);
          helpers.bump();
        },
      });
    };
  }

  return (
    <div className="explication-mouvement-widget">
      <span className="explication-mouvement-widget-label">Mouvement</span>
      <div className="explication-mouvement-widget-chips">
        <div
          ref={(el) => markTapSource(el)}
          className={`explication-mouvement-chip${armedKind === "open" ? " explication-mouvement-chip--armed" : ""}`}
          onPointerDown={handlePointerDown("open")}
          onPointerUp={handlePointerUp("open")}
          title="Crochet ouvrant"
        >
          [
        </div>
        <div
          ref={(el) => markTapSource(el)}
          className={`explication-mouvement-chip${armedKind === "close" ? " explication-mouvement-chip--armed" : ""}`}
          onPointerDown={handlePointerDown("close")}
          onPointerUp={handlePointerUp("close")}
          title="Crochet fermant"
        >
          ]
        </div>
      </div>
    </div>
  );
}

/* ---------- calque des traits entre marqueurs appariés ---------- */
// getPairs/assignLanes/allMarkers viennent maintenant de
// ../lib/overlayGeometry.js, partagé avec le rendu du fichier standalone
// exporté (voir lib/standalone.js) : une seule implémentation.

function OverlayLayer({ containerRef, helpers }) {
  const container = containerRef.current;
  if (!container) return null;

  const stageBox = container.parentElement.getBoundingClientRect();
  const items = getPairs(container);

  const LANE_BASE = 24, LANE_GAP = 28, LINE_WIDTH = 3, HIT_WIDTH = 16, DOT_SIZE = 8;
  const laned = assignLanes(items, allMarkers(container));

  // Réserve, dans .explication-canvas-wrap, assez de place à gauche du
  // texte pour que les traits (et leur zone cliquable élargie, plus
  // large que le trait visuel) ne soient jamais rognés par l'overflow du
  // wrap : la lane la plus excentrée détermine le point le plus à
  // gauche atteint par un trait (`lineLeft - (HIT_WIDTH-LINE_WIDTH)/2`),
  // --mouvement-gutter (lu par explication.css) doit couvrir au moins
  // cette distance. Sans mouvement affiché, on remet le gutter à 0 pour
  // ne pas garder un vide inutile une fois tous les mouvements retirés.
  const wrapEl = container.parentElement.parentElement;
  if (wrapEl) {
    const maxLane = laned.reduce((m, it) => Math.max(m, it.lane), -1);
    const gutter = maxLane < 0 ? 0 : LANE_BASE + maxLane * LANE_GAP + (HIT_WIDTH - LINE_WIDTH) / 2 + 12;
    wrapEl.style.setProperty("--mouvement-gutter", `${gutter}px`);
  }

  return (
    <div className="explication-mouvement-overlay">
      {laned.map((it) => {
        const top = it.openEl.getBoundingClientRect().top - stageBox.top;
        const bottom = it.closeEl.getBoundingClientRect().bottom - stageBox.top;
        const lineLeft = -LANE_BASE - it.lane * LANE_GAP;
        const hue = parseFloat(it.openEl.getAttribute("hue"));
        const color = Number.isFinite(hue) ? lineColor(hue) : "#664930";
        const open = () => helpers?.openPanel?.("mouvement", it.pid);

        return (
          <div key={it.pid}>
            {/* Clic sur le trait : ouvre le panneau et fait "bondir" sa card. */}
            <div
              role="button"
              tabIndex={0}
              title="Voir ce mouvement"
              onClick={open}
              onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && open()}
              className="explication-mouvement-line-hit"
              style={{ "--top": `${top}px`, "--height": `${Math.max(bottom - top, 20)}px`, "--left": `${lineLeft - (HIT_WIDTH - LINE_WIDTH) / 2}px` }}
            >
              <div className="explication-mouvement-line" style={{ "--line-color": color }} />
            </div>
            {[top, bottom].map((y, i) => (
              <div
                key={i}
                className="explication-mouvement-dot"
                style={{ "--top": `${y - DOT_SIZE / 2}px`, "--left": `${lineLeft + LINE_WIDTH / 2 - DOT_SIZE / 2}px`, "--dot-color": color }}
              />
            ))}
          </div>
        );
      })}
    </div>
  );
}

/* ---------- badge + panneau du bas ---------- */

function getBadge(container) {
  const items = getPairs(container);
  return items.length ? { label: "Mouvement", count: items.length } : null;
}

function PanelContent({ containerRef, version, helpers, bounceTarget }) {
  const container = containerRef.current;
  const items = container ? getPairs(container) : [];
  const { order, byId, bouncingId, startCardDrag, setCardRef } = usePanelList({
    items,
    idKey: "pid",
    toolId: "mouvement",
    version,
    bounceTarget,
    onDelete(pid) {
      const it = items.find((x) => x.pid === pid);
      if (it) {
        it.openEl.remove();
        it.closeEl.remove();
      }
      helpers.bump();
    },
  });

  if (order.length === 0) return <p className="explication-panel-empty">Aucun mouvement pour l’instant.</p>;

  return (
    <div className="explication-panel-list">
      {order.map((pid) => {
        const it = byId.get(pid);
        if (!it) return null;
        const hue = parseFloat(it.openEl.getAttribute("hue"));
        const color = Number.isFinite(hue) ? lineColor(hue) : "#664930";
        const soft = Number.isFinite(hue) ? `hsl(${hue}, 55%, 93%)` : "#f2e9de";

        return (
          <ExplicationCard
            key={pid}
            cardRef={setCardRef(pid)}
            accentColor={color}
            background={soft}
            bouncing={bouncingId === pid}
            onGripPointerDown={startCardDrag(pid)}
            title={{
              value: it.openEl.getAttribute("label") || "",
              placeholder: "Titre du mouvement…",
              onChange: (val) => it.openEl.setAttribute("label", val),
            }}
            description={{
              value: it.openEl.getAttribute("description") || "",
              placeholder: "Description…",
              onChange: (val) => it.openEl.setAttribute("description", val),
            }}
          />
        );
      })}
    </div>
  );
}

/* ---------- export du tool ---------- */

export default {
  id: "mouvement",
  label: "Mouvement",
  icon: "[ ]",
  description: "Glisser un crochet ouvrant et un crochet fermant pour délimiter un mouvement du texte.",
  order: 10,
  snap: snapBetweenWords, // dépôt ENTRE deux mots ; pas de `ghost` custom, le chip cliqué suffit (voir startDrag dans ExplicationEditor)

  ToolbarWidget,
  OverlayLayer,
  getBadge,
  PanelContent,

  // Marqueurs pré-existants dans le HTML importé : on leur attache leur
  // comportement, et on colore les paires déjà formées mais sans teinte.
  hydrate(container, helpers) {
    allMarkers(container).forEach((el) => attachHandlers(el, container, helpers));

    const byPair = new Map();
    allMarkers(container).forEach((el) => {
      const pid = el.getAttribute("pair");
      if (!pid) return;
      if (!byPair.has(pid)) byPair.set(pid, []);
      byPair.get(pid).push(el);
    });
    byPair.forEach((els) => {
      if (els.some((el) => el.hasAttribute("hue"))) return;
      const hue = nextHue();
      els.forEach((el) => {
        el.setAttribute("hue", hue);
        applyPairColor(el, hue);
      });
    });

    // Tap-à-tap (mobile) : second tap du placement + tap sur la poubelle.
    // Mécanique générique, voir lib/tapPlace.js — idempotent, donc sans
    // risque même si `hydrate` est rappelé.
    wireTapCanvas(container, helpers);
    wireTapTrash(helpers);
  },

  onDrop({ range, payload, container, helpers }) {
    const el = createMarker(payload.kind);
    range.insertNode(el);
    attachHandlers(el, container, helpers);
    pairAfterInsert(el, container, helpers.bump);
    helpers.bump();
  },
};
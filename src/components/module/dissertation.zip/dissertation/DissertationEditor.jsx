import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  ReactFlow, ReactFlowProvider, Background, Controls,
  useNodesState, useEdgesState, useReactFlow, Handle, Position,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import "./dissertation.css";
import StepPanel from "./StepPanel";
import steps from "./stepRegistry";
import { useFullscreen } from "./lib/fullscreenSystem";

// Une étape peut remplacer le rendu du sujet (ex. mots cliquables de « Définition »).
const CustomSubjectText = steps.find((s) => s.SubjectText)?.SubjectText;

/** Icône plein écran : coins vers l'extérieur (entrer) ou vers l'intérieur (quitter). */
function FullscreenIcon({ exit }) {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {exit ? (
        <path d="M9 4v5H4M15 4v5h5M20 15h-5v5M4 15h5v5" />
      ) : (
        <path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5" />
      )}
    </svg>
  );
}

// Poignées d'arrivée du sujet, une par côté (id « in-<côté> ») : les nœuds reliés au sujet
// (ex. la reformulation) choisissent le côté qui leur fait face.
const SUBJECT_IN = [
  ["top", Position.Top],
  ["right", Position.Right],
  ["bottom", Position.Bottom],
  ["left", Position.Left],
];

/** Nœud central : le sujet de la dissertation. */
function SubjectNode({ data }) {
  const Text = CustomSubjectText;
  return (
    <div className="dissertation-subject-node">
      {SUBJECT_IN.map(([side, position]) => (
        <Handle
          key={side}
          id={`in-${side}`}
          type="target"
          position={position}
          isConnectable={false}
          className="dissertation-handle"
        />
      ))}
      {Text ? <Text text={data.label} /> : <p>{data.label}</p>}
      <Handle type="source" position={Position.Bottom} className="dissertation-handle" />
    </div>
  );
}

/**
 * Enveloppe l'éditeur des `Provider` déclarés par les étapes (état propre à chaque étape).
 * Chaque Provider reçoit `status` : "locked" | "current" | "done".
 */
function StepProviders({ subject, validated, canvas, children }) {
  const currentId = steps.find((s) => !validated.includes(s.id))?.id;
  return steps.reduceRight((acc, step) => {
    if (!step.Provider) return acc;
    const status = validated.includes(step.id) ? "done" : step.id === currentId ? "current" : "locked";
    return (
      <step.Provider key={step.id} subject={subject} status={status} canvas={canvas}>
        {acc}
      </step.Provider>
    );
  }, children);
}

// Défini hors du composant : React Flow exige une référence stable.
// Les étapes peuvent déclarer leurs propres types de nœuds (step.nodeTypes).
const nodeTypes = Object.assign({ subject: SubjectNode }, ...steps.map((s) => s.nodeTypes));
// Idem pour les types de liens (step.edgeTypes).
const edgeTypes = Object.assign({}, ...steps.map((s) => s.edgeTypes));

/** Écran d'entrée : saisie du sujet. */
function SubjectForm({ onSubmit, fullscreen }) {
  const [value, setValue] = useState("");
  const submit = (e) => {
    e.preventDefault();
    const subject = value.trim();
    if (subject) onSubmit(subject);
  };

  return (
    <form className="dissertation-intro" onSubmit={submit}>
      <span className="eyebrow">Dissertation</span>
      <h1>Quel est votre sujet ?</h1>
      <textarea
        autoFocus
        rows={3}
        value={value}
        placeholder="Ex. : Peut-on être heureux sans être libre ?"
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) submit(e);
        }}
      />
      <button type="submit" className="dissertation-validate" disabled={!value.trim()}>
        Valider le sujet
      </button>
      {fullscreen.supported && (
        <p className="dissertation-fs-hint">
          <button type="button" className="dissertation-fs-hint-btn" onClick={fullscreen.toggle}>
            {fullscreen.isFullscreen ? "Quitter le plein écran" : "Passer en plein écran"}
          </button>
        </p>
      )}
      <Link to="/" className="dissertation-back">
        ← Retour à l’accueil
      </Link>
    </form>
  );
}

function Editor() {
  const [subject, setSubject] = useState(null);
  const [validated, setValidated] = useState([]);
  const [toolId, setToolId] = useState(null);
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const rf = useReactFlow();

  // API du canevas donnée aux étapes (Provider) : elles y ajoutent leurs nœuds et liens.
  const canvas = useMemo(
    () => ({
      setNodes,
      setEdges,
      getNodes: rf.getNodes,
      screenToFlowPosition: rf.screenToFlowPosition,
    }),
    [setNodes, setEdges, rf]
  );
  const fullscreen = useFullscreen();

  const ActiveTool = useMemo(
    () => (toolId ? steps.flatMap((s) => s.tools).find((t) => t.id === toolId)?.Component ?? null : null),
    [toolId]
  );

  const startWithSubject = (text) => {
    setNodes([{ id: "subject", type: "subject", position: { x: 0, y: 0 }, data: { label: text } }]);
    setSubject(text);
  };

  const [stepError, setStepError] = useState(null);

  // Le message disparaît dès que le nombre de nœuds change (ajout/suppression d'une définition).
  useEffect(() => {
    setStepError(null);
  }, [nodes.length]);

  const validateStep = (id) => {
    const error = steps.find((s) => s.id === id)?.validate?.({ nodes, edges });
    if (error) {
      setStepError(error);
      return;
    }
    setStepError(null);
    setValidated((v) => (v.includes(id) ? v : [...v, id]));
  };

  return (
    <div className="dissertation-editor">
      {fullscreen.supported && (
        <button
          type="button"
          className="dissertation-fullscreen"
          onClick={fullscreen.toggle}
          aria-label={fullscreen.isFullscreen ? "Quitter le plein écran" : "Passer en plein écran"}
          title={fullscreen.isFullscreen ? "Quitter le plein écran" : "Plein écran"}
        >
          <FullscreenIcon exit={fullscreen.isFullscreen} />
        </button>
      )}

      {subject === null ? (
        <SubjectForm onSubmit={startWithSubject} fullscreen={fullscreen} />
      ) : (
        <StepProviders subject={subject} validated={validated} canvas={canvas}>
          <>
            <div className="dissertation-canvas">
              <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                nodeTypes={nodeTypes}
                edgeTypes={edgeTypes}
                fitView
                zoomOnDoubleClick={false} // le double-clic dans le vide crée une connaissance (étape 5)
                fitViewOptions={{ maxZoom: 1, padding: 0.5 }}
                minZoom={0.1}
                maxZoom={3}
                proOptions={{ hideAttribution: true }}
              >
                <Background gap={28} size={1.5} color="#d9cfc2" />
                <Controls showInteractive={false} position="bottom-right" />
              </ReactFlow>
            </div>

            <StepPanel validated={validated} onValidate={validateStep} onOpenTool={setToolId} error={stepError} />

            {ActiveTool && <ActiveTool subject={subject} onClose={() => setToolId(null)} />}
          </>
        </StepProviders>
      )}
    </div>
  );
}

export default function DissertationEditor() {
  return (
    <ReactFlowProvider>
      <Editor />
    </ReactFlowProvider>
  );
}
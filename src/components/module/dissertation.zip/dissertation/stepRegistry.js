/**
 * Registre des étapes du parcours de rédaction (module dissertation).
 *
 * Chaque étape est un DOSSIER dans ./steps/, détecté automatiquement au
 * build par import.meta.glob : ajouter un dossier suffit, sans toucher à
 * ce registre ni à DissertationEditor.jsx.
 *
 *   steps/
 *   └── 01-definition/
 *       ├── step.js          ← infos de l'étape (export par défaut)
 *       └── tools/           ← outils propres à cette étape (optionnel)
 *           └── xxx.jsx
 *
 * Contrat de step.js (export par défaut) :
 *
 *   export default {
 *     id: "definition",            // identifiant unique et stable
 *     title: "Définition",         // libellé affiché dans le panneau
 *     description: "...",          // texte d'aide sous le titre de l'étape en cours
 *     order: 10,                   // optionnel, ordre croissant (à défaut : ordre du nom de dossier)
 *
 *     // Optionnels : une étape peut être un module autonome (état, UI, styles dans son dossier)
 *     Provider: Component,         // reçoit { subject, status, canvas, children } ; enveloppe l'éditeur.
 *                                  //   status : "locked" | "current" | "done"
 *                                  //   canvas : { setNodes, setEdges, getNodes, screenToFlowPosition }
 *     nodeTypes: { type: Component }, // types de nœuds React Flow ajoutés par l'étape
 *     edgeTypes: { type: Component }, // types de liens React Flow ajoutés par l'étape
 *     SubjectText: Component,      // reçoit { text } ; remplace le rendu du sujet (la première étape qui en déclare un)
 *     validate: ({ nodes, edges }) => string | null, // message d'erreur qui bloque « Valider l'étape » (null = OK)
 *   };
 *
 * Contrat d'un fichier outil (export par défaut) :
 *
 *   export default {
 *     id: "xxx", label: "Libellé", icon: "✎", description: "infobulle",
 *     order: 10,                   // optionnel
 *     Component: Dialog,           // optionnel : surcouche ouverte au clic, reçoit { subject, onClose }
 *   };                             //   (rendue dans le Provider de l'étape ; id d'outil unique)
 *
 * Ne vont dans ./lib que les éléments communs à toutes les étapes.
 */

const stepModules = import.meta.glob("./steps/*/step.js", { eager: true });
const toolModules = import.meta.glob("./steps/*/tools/*.{js,jsx}", { eager: true });

// "./steps/01-definition/step.js" -> "01-definition"
const folderOf = (path) => path.split("/")[2];

const toolsByFolder = {};
for (const [path, mod] of Object.entries(toolModules)) {
  const tool = mod.default;
  if (!tool || !tool.id) {
    console.warn(`[module/dissertation] outil ignoré (export par défaut invalide) : ${path}`);
    continue;
  }
  (toolsByFolder[folderOf(path)] ??= []).push(tool);
}
for (const list of Object.values(toolsByFolder)) {
  list.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

const steps = Object.entries(stepModules)
  .map(([path, mod]) => {
    const step = mod.default;
    if (!step || !step.id || !step.title) {
      console.warn(`[module/dissertation] étape ignorée (export par défaut invalide) : ${path}`);
      return null;
    }
    const folder = folderOf(path);
    return { ...step, folder, tools: toolsByFolder[folder] ?? [] };
  })
  .filter(Boolean)
  .sort(
    (a, b) =>
      (a.order ?? 0) - (b.order ?? 0) || a.folder.localeCompare(b.folder, "fr", { numeric: true })
  );

export default steps;
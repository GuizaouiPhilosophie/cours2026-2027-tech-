import Provider from "./ProblematiqueProvider";
import ProblematiqueNode from "./components/ProblematiqueNode";

export default {
  id: "problematique",
  title: "Problématique",
  description: "Cliquez sur le sujet pour formuler la problématique à partir de vos définitions et contradictions.",
  order: 40,
  Provider,
  nodeTypes: { problematique: ProblematiqueNode },
  // Un texte non vide, formulé comme une question.
  validate: ({ nodes }) => {
    const text = nodes.find((n) => n.type === "problematique")?.data?.text?.trim() ?? "";
    if (!text) return "Rédigez votre problématique pour passer à l'étape suivante.";
    if (!text.includes("?")) return "Votre problématique doit prendre la forme d'une question.";
    return null;
  },
};

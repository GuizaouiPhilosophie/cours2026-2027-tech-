import { useCallback, useEffect, useMemo, useState } from "react";
import "./problematique.css";
import { ProblematiqueContext } from "./context";
import { useDefinitions } from "../01-definition/context";
import { useContradictions } from "../03-contradictions/context";
import { EDGE_STYLE, DEF_Z_INDEX, EDGE_Z_INDEX } from "../01-definition/lib/placement";
import ProblematiqueBubble from "./components/ProblematiqueBubble";

const NODE_ID = "problematique";
const NODE_W = 300;
const DROP = 140; // distance sous le nœud le plus bas de la carte (flow units)

/**
 * Provider de l'étape : possède le texte de la problématique et sa bulle, et le reflète
 * sur le canevas (un nœud sous la carte, relié au sujet ; la reformulation est au-dessus).
 * Rendu à l'intérieur des Providers « Définition » et « Contradictions » : il lit leurs états.
 * Ouverture : clic sur le nœud du sujet ou sur le nœud de problématique.
 */
export default function ProblematiqueProvider({ subject, status, canvas, children }) {
  const { definitions } = useDefinitions();
  const { contradictions } = useContradictions();
  const [text, setText] = useState("");
  const [anchor, setAnchor] = useState(null);
  const enabled = status === "current";

  const open = useCallback((el) => {
    const r = el.getBoundingClientRect();
    setAnchor({ x: r.left + r.width / 2, top: r.top, bottom: r.bottom });
  }, []);
  const close = useCallback(() => setAnchor(null), []);

  // Clic sur le sujet (sans glissement : le nœud reste déplaçable).
  useEffect(() => {
    if (!enabled) return;
    let start = null;
    const subjectEl = (e) => e.target.closest?.(".dissertation-subject-node");
    const down = (e) => {
      start = subjectEl(e) ? { x: e.clientX, y: e.clientY } : null;
    };
    const click = (e) => {
      const el = subjectEl(e);
      if (!el || !start) return;
      if (Math.hypot(e.clientX - start.x, e.clientY - start.y) > 5) return;
      open(el);
    };
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("click", click, true);
    return () => {
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("click", click, true);
    };
  }, [enabled, open]);

  /** Enregistre la problématique à chaque frappe ; un texte vide supprime le nœud. */
  const change = useCallback(
    (next) => {
      setText(next);

      if (!next.trim()) {
        canvas.setNodes((ns) => ns.filter((n) => n.id !== NODE_ID));
        canvas.setEdges((es) => es.filter((e) => e.id !== NODE_ID));
        return;
      }

      const ns = canvas.getNodes();
      if (ns.some((n) => n.id === NODE_ID)) {
        canvas.setNodes((list) =>
          list.map((n) => (n.id === NODE_ID ? { ...n, data: { ...n.data, text: next } } : n))
        );
        return;
      }

      // Centré sous le sujet, en dessous de tout ce qui est déjà sur la carte.
      const subj = ns.find((n) => n.id === "subject");
      const sx = (subj?.position.x ?? 0) + (subj?.measured?.width ?? NODE_W) / 2;
      const lowest = Math.max(...ns.map((n) => n.position.y + (n.measured?.height ?? 0)));

      canvas.setNodes((list) => [
        ...list,
        {
          id: NODE_ID,
          type: "problematique",
          zIndex: DEF_Z_INDEX,
          position: { x: sx - NODE_W / 2, y: lowest + DROP },
          data: { text: next },
        },
      ]);
      canvas.setEdges((es) => [
        ...es,
        {
          id: NODE_ID,
          source: NODE_ID,
          sourceHandle: "out-top", // côtés ajustés ensuite par le nœud (facingNodeSide)
          target: "subject",
          targetHandle: "in-bottom",
          style: EDGE_STYLE,
          zIndex: EDGE_Z_INDEX,
        },
      ]);
    },
    [canvas]
  );

  const value = useMemo(() => ({ open: enabled ? open : null }), [enabled, open]);

  return (
    <ProblematiqueContext.Provider value={value}>
      {children}
      {enabled && anchor && (
        <ProblematiqueBubble
          subject={subject}
          anchor={anchor}
          definitions={definitions}
          contradictions={contradictions}
          nodes={canvas.getNodes()}
          text={text}
          onChange={change}
          onClose={close}
        />
      )}
    </ProblematiqueContext.Provider>
  );
}

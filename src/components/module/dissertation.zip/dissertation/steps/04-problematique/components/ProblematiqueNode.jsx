import { useEffect } from "react";
import { Handle, useInternalNode, useReactFlow } from "@xyflow/react";
import { useProblematique } from "../context";
import { SIDES, OPPOSITE, POSITION, childHandle, facingNodeSide } from "../../01-definition/lib/placement";

/**
 * Nœud de la carte mentale : la problématique, reliée au sujet.
 * Même logique que ReformulationNode : le lien part du côté qui regarde le sujet
 * et arrive sur la poignée `in-<côté>` du sujet qui regarde ce nœud.
 */
export default function ProblematiqueNode({ id, data }) {
  const { open } = useProblematique();
  const { setEdges } = useReactFlow();
  const self = useInternalNode(id);
  const subject = useInternalNode("subject");

  const side = facingNodeSide(self, subject); // côté du SUJET qui fait face à ce nœud

  useEffect(() => {
    if (!side) return;
    const sourceHandle = childHandle(OPPOSITE[side]);
    const targetHandle = `in-${side}`;
    setEdges((es) =>
      es.some((e) => e.id === id && (e.sourceHandle !== sourceHandle || e.targetHandle !== targetHandle))
        ? es.map((e) => (e.id === id ? { ...e, sourceHandle, targetHandle } : e))
        : es
    );
  }, [side, id, setEdges]);

  const go = (e) => open?.(e.currentTarget);
  return (
    <div
      className="dissertation-problemnode"
      role={open ? "button" : undefined}
      tabIndex={open ? 0 : undefined}
      title={open ? "Modifier la problématique" : undefined}
      onClick={open ? go : undefined}
      onKeyDown={open ? (e) => (e.key === "Enter" || e.key === " ") && go(e) : undefined}
    >
      {SIDES.map((s) => (
        <Handle key={`in-${s}`} id={s} type="target" position={POSITION[s]} isConnectable={false} className="dissertation-handle" />
      ))}
      {SIDES.map((s) => (
        <Handle
          key={s}
          id={childHandle(s)}
          type="source"
          position={POSITION[s]}
          isConnectable={false}
          className="dissertation-handle"
        />
      ))}
      <span className="dissertation-problemnode-label">Problématique</span>
      <p>{data.text}</p>
    </div>
  );
}

import { describe } from "../../03-contradictions/lib/describe";

/** Contradictions de l'étape 3 : « A ⟷ B » puis le commentaire. */
export default function ContradictionList({ contradictions, nodes }) {
  const list = Object.values(contradictions);
  if (list.length === 0) return <p className="dissertation-tools-empty">Aucune contradiction.</p>;

  return (
    <ul className="dissertation-problem-row">
      {list.map((c) => {
        const a = describe(c.a, nodes, contradictions);
        const b = describe(c.b, nodes, contradictions);
        const comment = c.text.trim();
        return (
          <li key={c.id} className="dissertation-problem-card is-contra">
            <strong>
              {a.label} <span aria-label="contre">⟷</span> {b.label}
            </strong>
            {comment ? <p>{comment}</p> : <p className="is-empty">Sans commentaire</p>}
          </li>
        );
      })}
    </ul>
  );
}

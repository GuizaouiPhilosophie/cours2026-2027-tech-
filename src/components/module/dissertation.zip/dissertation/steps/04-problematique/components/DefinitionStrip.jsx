import { useMemo, useState } from "react";
import { byId, tokenize } from "../../01-definition/lib/definitions";

/**
 * Définitions rédigées : une pastille par mot défini (dans l'ordre du sujet) ;
 * une pastille ouverte affiche ses définitions puis les définitions liées (nœuds enfants).
 * Mobile : pastilles et cartes défilent horizontalement (voir problematique.css).
 */
export default function DefinitionStrip({ subject, definitions, nodes }) {
  const [openKey, setOpenKey] = useState(null);

  const words = useMemo(() => {
    const seen = new Set();
    return tokenize(subject).filter((t) => {
      if (t.type !== "word" || seen.has(t.key) || !definitions[t.key]?.length) return false;
      seen.add(t.key);
      return true;
    });
  }, [subject, definitions]);

  if (words.length === 0) return <p className="dissertation-tools-empty">Aucune définition rédigée.</p>;

  const linked = nodes.filter((n) => n.type === "definition" && n.data?.parent);
  const descendants = (id) =>
    linked.filter((n) => n.data.parent === id).flatMap((n) => [n, ...descendants(n.id)]);

  // Cartes à plat : chaque définition, suivie de ses définitions liées.
  const cards = openKey
    ? (definitions[openKey] ?? []).flatMap((d) => {
        const src = d.source ? byId.get(d.source) : null;
        return [
          { id: d.id, note: src ? `Glossaire : ${src.terme}` : null, text: d.text },
          ...descendants(`def-${openKey}-${d.id}`).map((n) => ({
            id: n.id,
            note: `Liée : ${n.data.word}`,
            text: n.data.text,
            linked: true,
          })),
        ];
      })
    : [];

  return (
    <>
      <div className="dissertation-chips dissertation-problem-chips">
        {words.map((w) => (
          <button
            key={w.key}
            type="button"
            className={`dissertation-chip${openKey === w.key ? " is-active" : ""}`}
            aria-expanded={openKey === w.key}
            onClick={() => setOpenKey((k) => (k === w.key ? null : w.key))}
          >
            {w.text}
            {definitions[w.key].length > 1 ? ` (${definitions[w.key].length})` : ""}
          </button>
        ))}
      </div>

      {cards.length > 0 && (
        <ul className="dissertation-problem-row">
          {cards.map((c) => (
            <li key={c.id} className={`dissertation-problem-card${c.linked ? " is-linked" : ""}`}>
              {c.note && <span className="dissertation-problem-note">{c.note}</span>}
              <p>{c.text}</p>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

import { useEffect, useMemo, useRef } from "react";
import useEscape from "../../../lib/useEscape";
import useSheetViewport from "../../../lib/useSheetViewport";
import DefinitionStrip from "./DefinitionStrip";
import ContradictionList from "./ContradictionList";

const MAX_W = 760;
const NARROW = 640;
const COMPACT_H = 560; // en dessous (clavier ouvert, petit téléphone) : on masque la reformulation
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

/** Grand écran : bulle sous (ou au-dessus) du sujet. Petit écran : plein écran. */
function place(anchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (!anchor || vw < NARROW) return { sheet: true, style: {} };

  const width = Math.min(MAX_W, vw - 16);
  const left = clamp(anchor.x - width / 2, 8, vw - width - 8);
  const arrow = clamp(anchor.x - left, 24, width - 24);
  const room = vh - anchor.bottom;

  return room >= 420 || room >= anchor.top
    ? { side: "below", arrow, style: { left, width, top: anchor.bottom + 12, maxHeight: room - 20 } }
    : { side: "above", arrow, style: { left, width, bottom: vh - anchor.top + 12, maxHeight: anchor.top - 20 } };
}

/**
 * Bulle de problématique.
 *  - PC : deux colonnes, matériaux à gauche (sujet, reformulation, définitions, contradictions),
 *         écriture à droite ;
 *  - mobile : plein écran vertical, sans défilement vertical. Matériaux en haut (définitions et
 *         contradictions défilent horizontalement), zone d'écriture qui prend toute la place restante.
 */
export default function ProblematiqueBubble({
  subject, anchor, definitions, contradictions, nodes, text, onChange, onClose,
}) {
  const ref = useRef(null);
  const pos = useMemo(() => place(anchor), [anchor]);
  const sheet = useSheetViewport(pos.sheet); // petit écran : plein écran
  const compact = sheet.height !== null && sheet.height < COMPACT_H;
  const reformulation = nodes.find((n) => n.id === "reformulation")?.data?.text ?? "";

  useEscape(onClose);

  useEffect(() => {
    const onDown = (e) => {
      if (ref.current?.contains(e.target)) return;
      if (e.target.closest?.(".dissertation-subject-node, .dissertation-problemnode")) return; // ils (ré)ouvrent la bulle
      onClose();
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [onClose]);

  const style = pos.sheet ? sheet.style : { ...pos.style, "--arrow-x": `${pos.arrow}px` };

  return (
    <div
      ref={ref}
      className={`dissertation-bubble is-workspace ${pos.sheet ? "is-sheet" : `is-${pos.side}`}${compact ? " is-compact" : ""}`}
      style={style}
      role="dialog"
      aria-label="Problématique"
    >
      <div className="dissertation-bubble-body">
        <div className="dissertation-bubble-head">
          <h2>Problématique</h2>
          <button type="button" className="dissertation-close" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>

        <div className="dissertation-problem-layout">
          <div className="dissertation-problem-sources">
            <div className="dissertation-problem-block">
              <span>Sujet</span>
              <p className="dissertation-problem-subject">{subject}</p>
            </div>

            {reformulation.trim() && (
              <div className="dissertation-problem-block dissertation-problem-reform">
                <span>Votre reformulation</span>
                <p>{reformulation}</p>
              </div>
            )}

            <div className="dissertation-problem-block">
              <span>Définitions</span>
              <DefinitionStrip subject={subject} definitions={definitions} nodes={nodes} />
            </div>

            <div className="dissertation-problem-block">
              <span>Contradictions ({Object.keys(contradictions).length})</span>
              <ContradictionList contradictions={contradictions} nodes={nodes} />
            </div>
          </div>

          <label className="dissertation-field dissertation-problem-write">
            <span>Votre problématique</span>
            <textarea
              autoFocus={!pos.sheet} // mobile : pas de clavier à l'ouverture, les matériaux restent lisibles
              value={text}
              placeholder="Partez d'une contradiction pour formuler la question que pose le sujet…"
              onChange={(e) => onChange(e.target.value)}
            />
          </label>
        </div>
      </div>
    </div>
  );
}

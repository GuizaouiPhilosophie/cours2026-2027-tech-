import { createContext, useContext } from "react";

/** open : (élément) => void ; null tant que l'étape n'est pas l'étape courante. */
export const ProblematiqueContext = createContext({ open: null });
export const useProblematique = () => useContext(ProblematiqueContext);

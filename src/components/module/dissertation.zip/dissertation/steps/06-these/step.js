import Provider from "./TheseProvider";
import TheseNode from "./components/TheseNode";

export default {
  id: "these",
  title: "Thèse",
  description: "Cliquez sur la problématique pour proposer votre réponse.",
  order: 60,
  Provider,
  nodeTypes: { these: TheseNode },
  validate: ({ nodes }) =>
    nodes.some((n) => n.type === "these" && n.data?.text?.trim())
      ? null
      : "Rédigez votre thèse pour passer à l'étape suivante.",
};

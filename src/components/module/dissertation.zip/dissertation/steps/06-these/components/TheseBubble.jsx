import { useEffect, useMemo, useRef } from "react";
import useEscape from "../../../lib/useEscape";
import useSheetViewport from "../../../lib/useSheetViewport";
import DefinitionStrip from "../../04-problematique/components/DefinitionStrip";
import ContradictionList from "../../04-problematique/components/ContradictionList";
import KnowledgeList from "./KnowledgeList";

const MAX_W = 760;
const NARROW = 640;
const COMPACT_H = 560; // clavier ouvert / petit téléphone : cartes plus basses
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

/** Grand écran : bulle sous (ou au-dessus) de la problématique. Petit écran : plein écran. */
function place(anchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (!anchor || vw < NARROW) return { sheet: true, style: {} };

  const width = Math.min(MAX_W, vw - 16);
  const left = clamp(anchor.x - width / 2, 8, vw - width - 8);
  const arrow = clamp(anchor.x - left, 24, width - 24);
  const room = vh - anchor.bottom;

  return room >= 420 || room >= anchor.top
    ? { side: "below", arrow, style: { left, width, top: anchor.bottom + 12, maxHeight: room - 20 } }
    : { side: "above", arrow, style: { left, width, bottom: vh - anchor.top + 12, maxHeight: anchor.top - 20 } };
}

/**
 * Bulle de la thèse : même mise en page que la problématique (.is-workspace, voir problematique.css).
 *  - PC : matériaux à gauche (problématique, connaissances, définitions, contradictions), écriture à droite ;
 *  - mobile : plein écran vertical, sans défilement vertical ; les listes défilent horizontalement.
 */
export default function TheseBubble({
  subject, anchor, definitions, contradictions, knowledge, links, nodes, text, onChange, onClose,
}) {
  const ref = useRef(null);
  const pos = useMemo(() => place(anchor), [anchor]);
  const sheet = useSheetViewport(pos.sheet);
  const compact = sheet.height !== null && sheet.height < COMPACT_H;
  const problem = nodes.find((n) => n.id === "problematique")?.data?.text ?? "";
  const knowCount = Object.values(knowledge).filter((k) => k.text.trim()).length;

  useEscape(onClose);

  useEffect(() => {
    const onDown = (e) => {
      if (ref.current?.contains(e.target)) return;
      if (e.target.closest?.(".dissertation-problemnode, .dissertation-thesisnode")) return; // ils (ré)ouvrent la bulle
      onClose();
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [onClose]);

  const style = pos.sheet ? sheet.style : { ...pos.style, "--arrow-x": `${pos.arrow}px` };

  return (
    <div
      ref={ref}
      className={`dissertation-bubble is-workspace is-thesis ${pos.sheet ? "is-sheet" : `is-${pos.side}`}${compact ? " is-compact" : ""}`}
      style={style}
      role="dialog"
      aria-label="Thèse"
    >
      <div className="dissertation-bubble-body">
        <div className="dissertation-bubble-head">
          <h2>Thèse</h2>
          <button type="button" className="dissertation-close" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>

        <div className="dissertation-problem-layout">
          <div className="dissertation-problem-sources">
            <div className="dissertation-problem-block">
              <span>Problématique</span>
              <p className="dissertation-thesis-question">{problem}</p>
            </div>

            <div className="dissertation-problem-block">
              <span>Connaissances ({knowCount})</span>
              <KnowledgeList knowledge={knowledge} links={links} nodes={nodes} contradictions={contradictions} />
            </div>

            <div className="dissertation-problem-block">
              <span>Définitions</span>
              <DefinitionStrip subject={subject} definitions={definitions} nodes={nodes} />
            </div>

            <div className="dissertation-problem-block">
              <span>Contradictions ({Object.keys(contradictions).length})</span>
              <ContradictionList contradictions={contradictions} nodes={nodes} />
            </div>
          </div>

          <label className="dissertation-field dissertation-problem-write">
            <span>Votre thèse</span>
            <textarea
              autoFocus={!pos.sheet} // mobile : pas de clavier à l'ouverture, les matériaux restent lisibles
              value={text}
              placeholder="Votre réponse à la problématique, appuyée sur vos connaissances…"
              onChange={(e) => onChange(e.target.value)}
            />
          </label>
        </div>
      </div>
    </div>
  );
}

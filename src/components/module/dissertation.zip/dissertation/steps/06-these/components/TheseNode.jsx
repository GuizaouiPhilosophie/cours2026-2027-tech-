import { useEffect } from "react";
import { Handle, useInternalNode, useReactFlow } from "@xyflow/react";
import { useThese } from "../context";
import { SIDES, OPPOSITE, POSITION, childHandle, facingNodeSide } from "../../01-definition/lib/placement";

const PARENT_ID = "problematique";

/**
 * Nœud de la carte mentale : la thèse, reliée à la problématique.
 * Le lien part du côté du nœud qui regarde la problématique et arrive sur la poignée
 * de la problématique qui regarde ce nœud (ProblematiqueNode déclare une poignée d'arrivée par côté).
 */
export default function TheseNode({ id, data }) {
  const { open } = useThese();
  const { setEdges } = useReactFlow();
  const self = useInternalNode(id);
  const parent = useInternalNode(PARENT_ID);

  const side = facingNodeSide(self, parent); // côté de la PROBLÉMATIQUE qui fait face à ce nœud

  useEffect(() => {
    if (!side) return;
    const sourceHandle = childHandle(OPPOSITE[side]);
    const targetHandle = side;
    setEdges((es) =>
      es.some((e) => e.id === id && (e.sourceHandle !== sourceHandle || e.targetHandle !== targetHandle))
        ? es.map((e) => (e.id === id ? { ...e, sourceHandle, targetHandle } : e))
        : es
    );
  }, [side, id, setEdges]);

  const go = (e) => open?.(e.currentTarget);
  return (
    <div
      className="dissertation-thesisnode"
      role={open ? "button" : undefined}
      tabIndex={open ? 0 : undefined}
      title={open ? "Modifier la thèse" : undefined}
      onClick={open ? go : undefined}
      onKeyDown={open ? (e) => (e.key === "Enter" || e.key === " ") && go(e) : undefined}
    >
      {SIDES.map((s) => (
        <Handle key={`in-${s}`} id={s} type="target" position={POSITION[s]} isConnectable={false} className="dissertation-handle" />
      ))}
      {SIDES.map((s) => (
        <Handle
          key={s}
          id={childHandle(s)}
          type="source"
          position={POSITION[s]}
          isConnectable={false}
          className="dissertation-handle"
        />
      ))}
      <span className="dissertation-thesisnode-label">Thèse</span>
      <p>{data.text}</p>
    </div>
  );
}

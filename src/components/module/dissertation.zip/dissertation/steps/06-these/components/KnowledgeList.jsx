import { describe } from "../../03-contradictions/lib/describe";

const KNOW = "connaissance";
const short = (t, n = 32) => (t.length > n ? `${t.slice(0, n).trimEnd()}…` : t);

/** Connaissances de l'étape 5 : le texte, puis les nœuds auxquels chacune est reliée. */
export default function KnowledgeList({ knowledge, links, nodes, contradictions }) {
  const list = Object.values(knowledge).filter((k) => k.text.trim());
  if (list.length === 0) return <p className="dissertation-tools-empty">Aucune connaissance.</p>;

  const label = (id) => {
    const n = nodes.find((x) => x.id === id);
    if (n?.type === KNOW) return short(knowledge[n.data.kid]?.text?.trim() || "Connaissance");
    return describe(id, nodes, contradictions).label;
  };

  return (
    <ul className="dissertation-problem-row">
      {list.map((k) => {
        const self = `know-${k.id}`;
        const linked = Object.values(links)
          .filter((l) => l.a === self || l.b === self)
          .map((l) => label(l.a === self ? l.b : l.a));
        return (
          <li key={k.id} className="dissertation-problem-card is-know">
            <p>{k.text}</p>
            {linked.length > 0 && <span className="dissertation-thesis-linked">Reliée à : {linked.join(", ")}</span>}
          </li>
        );
      })}
    </ul>
  );
}

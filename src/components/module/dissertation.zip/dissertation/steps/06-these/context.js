import { createContext, useContext } from "react";

/** open : (élément) => void ; null tant que l'étape n'est pas l'étape courante. */
export const TheseContext = createContext({ open: null });
export const useThese = () => useContext(TheseContext);

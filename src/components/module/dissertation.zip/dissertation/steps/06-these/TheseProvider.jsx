import { useCallback, useEffect, useMemo, useState } from "react";
import "../04-problematique/problematique.css"; // mise en page « .is-workspace » de la bulle
import "./these.css";
import { TheseContext } from "./context";
import { useDefinitions } from "../01-definition/context";
import { useContradictions } from "../03-contradictions/context";
import { useKnowledge } from "../05-connaissances/context";
import { EDGE_STYLE, DEF_Z_INDEX, EDGE_Z_INDEX } from "../01-definition/lib/placement";
import TheseBubble from "./components/TheseBubble";

const NODE_ID = "these";
const PARENT_ID = "problematique";
const NODE_W = 300;
const DROP = 140; // distance sous la problématique (flow units)

/**
 * Provider de l'étape : possède le texte de la thèse et sa bulle, et le reflète sur le canevas
 * (un nœud sous la problématique, relié à elle).
 * Rendu à l'intérieur des Providers des étapes 1 à 5 : il lit définitions, contradictions et connaissances.
 * Ouverture : clic sur le nœud de problématique ou sur le nœud de thèse.
 */
export default function TheseProvider({ subject, status, canvas, children }) {
  const { definitions } = useDefinitions();
  const { contradictions } = useContradictions();
  const { items, links } = useKnowledge();
  const [text, setText] = useState("");
  const [anchor, setAnchor] = useState(null);
  const enabled = status === "current";

  const open = useCallback((el) => {
    const r = el.getBoundingClientRect();
    setAnchor({ x: r.left + r.width / 2, top: r.top, bottom: r.bottom });
  }, []);
  const close = useCallback(() => setAnchor(null), []);

  // Clic sur la problématique (sans glissement : le nœud reste déplaçable).
  useEffect(() => {
    if (!enabled) return;
    let start = null;
    const problemEl = (e) => e.target.closest?.(".dissertation-problemnode");
    const down = (e) => {
      start = problemEl(e) ? { x: e.clientX, y: e.clientY } : null;
    };
    const click = (e) => {
      const el = problemEl(e);
      if (!el || !start) return;
      if (Math.hypot(e.clientX - start.x, e.clientY - start.y) > 5) return;
      open(el);
    };
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("click", click, true);
    return () => {
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("click", click, true);
    };
  }, [enabled, open]);

  /** Enregistre la thèse à chaque frappe ; un texte vide supprime le nœud. */
  const change = useCallback(
    (next) => {
      setText(next);

      if (!next.trim()) {
        canvas.setNodes((ns) => ns.filter((n) => n.id !== NODE_ID));
        canvas.setEdges((es) => es.filter((e) => e.id !== NODE_ID));
        return;
      }

      const ns = canvas.getNodes();
      if (ns.some((n) => n.id === NODE_ID)) {
        canvas.setNodes((list) =>
          list.map((n) => (n.id === NODE_ID ? { ...n, data: { ...n.data, text: next } } : n))
        );
        return;
      }

      const parent = ns.find((n) => n.id === PARENT_ID);
      const px = (parent?.position.x ?? 0) + (parent?.measured?.width ?? NODE_W) / 2;
      const py = (parent?.position.y ?? 0) + (parent?.measured?.height ?? 120);

      canvas.setNodes((list) => [
        ...list,
        {
          id: NODE_ID,
          type: "these",
          zIndex: DEF_Z_INDEX,
          position: { x: px - NODE_W / 2, y: py + DROP },
          data: { text: next },
        },
      ]);
      canvas.setEdges((es) => [
        ...es,
        {
          id: NODE_ID,
          source: NODE_ID,
          sourceHandle: "out-top", // côtés ajustés ensuite par le nœud (facingNodeSide)
          target: PARENT_ID,
          targetHandle: "bottom",
          style: EDGE_STYLE,
          zIndex: EDGE_Z_INDEX,
        },
      ]);
    },
    [canvas]
  );

  const value = useMemo(() => ({ open: enabled ? open : null }), [enabled, open]);

  return (
    <TheseContext.Provider value={value}>
      {children}

      {enabled && !anchor && (
        <div className="dissertation-thesisbar">
          <p className="dissertation-thesishint">Cliquez sur la problématique pour rédiger votre thèse.</p>
        </div>
      )}

      {enabled && anchor && (
        <TheseBubble
          subject={subject}
          anchor={anchor}
          definitions={definitions}
          contradictions={contradictions}
          knowledge={items}
          links={links}
          nodes={canvas.getNodes()}
          text={text}
          onChange={change}
          onClose={close}
        />
      )}
    </TheseContext.Provider>
  );
}

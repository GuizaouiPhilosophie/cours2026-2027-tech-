import { useEffect, useRef, useState } from "react";
import { Handle, Position } from "@xyflow/react";
import { useContradictions } from "../context";
import { rectAnchor } from "../lib/anchor";

/**
 * Nœud d'intersection : le commentaire d'une contradiction entre deux nœuds.
 * Un clic sur le nœud sert à le relier (géré par ContradictionProvider, comme pour les autres nœuds) ;
 * il fait aussi apparaître un crayon au-dessus, qui ouvre l'édition du commentaire.
 */
export default function ContradictionNode({ data }) {
  const { open, contradictions } = useContradictions();
  const text = contradictions[data.cid]?.text ?? "";
  const [showEdit, setShowEdit] = useState(false);
  const ref = useRef(null);
  const down = useRef(null);

  // Cache le crayon en cliquant ailleurs.
  useEffect(() => {
    if (!showEdit) return;
    const close = (e) => !ref.current?.contains(e.target) && setShowEdit(false);
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [showEdit]);

  return (
    <div
      ref={ref}
      className="dissertation-contranode"
      onPointerDown={(e) => (down.current = { x: e.clientX, y: e.clientY })}
      onClick={(e) => {
        if (e.target.closest(".dissertation-contra-edit")) return;
        const d = down.current;
        if (d && Math.hypot(e.clientX - d.x, e.clientY - d.y) > 5) return; // le nœud vient d'être déplacé
        setShowEdit((v) => !v);
      }}
    >
      {/* Une poignée par type suffit : le tracé du lien est calculé par ContradictionEdge. */}
      <Handle type="target" position={Position.Top} isConnectable={false} className="dissertation-handle" />
      <Handle type="source" position={Position.Bottom} isConnectable={false} className="dissertation-handle" />
      {showEdit && open && (
        <button
          type="button"
          className="dissertation-contra-edit nodrag nopan"
          aria-label="Modifier le commentaire"
          title="Modifier le commentaire"
          onClick={(e) => {
            setShowEdit(false);
            open(data.cid, rectAnchor(ref.current ?? e.currentTarget));
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
          </svg>
        </button>
      )}
      <span className="dissertation-contranode-label">Contradiction</span>
      <p>{text.trim() ? text : <em>Sans commentaire</em>}</p>
    </div>
  );
}
import { useEffect, useMemo, useRef } from "react";
import useEscape from "../../../lib/useEscape";
import useSheetViewport from "../../../lib/useSheetViewport";

const WIDTH = 380;
const NARROW = 640;
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

/** Même placement que DefinitionBubble ; « feuille » en haut sur petit écran. */
function place(anchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (!anchor || vw < NARROW) return { sheet: true, style: {} };

  const left = clamp(anchor.x - WIDTH / 2, 8, vw - WIDTH - 8);
  const arrow = clamp(anchor.x - left, 24, WIDTH - 24);
  const room = vh - anchor.bottom;

  return room >= 320 || room >= anchor.top
    ? { side: "below", arrow, style: { left, top: anchor.bottom + 12, maxHeight: room - 20 } }
    : { side: "above", arrow, style: { left, bottom: vh - anchor.top + 12, maxHeight: anchor.top - 20 } };
}

/**
 * Bulle d'une contradiction : les deux éléments reliés, puis le commentaire (enregistré à
 * chaque frappe). Sans commentaire, seul le lien rouge existe ; avec, un nœud d'intersection apparaît.
 * `ends` : [{ label, text? }, { label, text? }]
 */
export default function ContradictionBubble({ ends, anchor, text, readOnly, onChange, onDelete, onClose }) {
  const ref = useRef(null);
  const pos = useMemo(() => place(anchor), [anchor]);
  const sheet = useSheetViewport(pos.sheet); // petit écran : plein écran

  useEscape(onClose);

  useEffect(() => {
    const onDown = (e) => {
      if (!ref.current?.contains(e.target)) onClose();
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className={`dissertation-bubble ${pos.sheet ? "is-sheet" : `is-${pos.side}`}`}
      style={{ ...pos.style, ...sheet.style, "--arrow-x": `${pos.arrow ?? 0}px` }}
      role="dialog"
      aria-label="Contradiction"
    >
      <div className="dissertation-bubble-body">
        <div className="dissertation-bubble-head">
          <h2>Contradiction</h2>
          <button type="button" className="dissertation-close" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>

        <div className="dissertation-contra-ends">
          {ends.map((e, i) => (
            <div key={i} className="dissertation-contra-end">
              <strong>{e.label}</strong>
              {e.text?.trim() && <p>{e.text}</p>}
            </div>
          ))}
        </div>

        <label className="dissertation-field dissertation-field-grow">
          <span>Votre commentaire</span>
          <textarea
            autoFocus
            rows={5}
            value={text}
            readOnly={readOnly}
            placeholder="En quoi se contredisent-ils ? (facultatif : sans texte, seul le lien est conservé)"
            onChange={(e) => onChange(e.target.value)}
          />
        </label>

        {!readOnly && (
          <button type="button" className="dissertation-contra-delete" onClick={onDelete}>
            Supprimer le lien
          </button>
        )}
      </div>
    </div>
  );
}

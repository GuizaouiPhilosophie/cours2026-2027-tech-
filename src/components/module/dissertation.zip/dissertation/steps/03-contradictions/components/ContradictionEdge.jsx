import { BaseEdge, getStraightPath, useInternalNode } from "@xyflow/react";
import { useContradictions } from "../context";
import { borderPoint } from "../../../lib/floatingEdge";

/**
 * Lien rouge « flottant » : il relie les bords des deux nœuds, quel que soit l'endroit où
 * on les déplace (pas de poignée à choisir). Un clic ouvre l'édition du commentaire.
 */
export default function ContradictionEdge({ id, source, target, data, style }) {
  const s = useInternalNode(source);
  const t = useInternalNode(target);
  const { open } = useContradictions();
  if (!s?.measured?.width || !t?.measured?.width) return null;

  const a = borderPoint(s, t);
  const b = borderPoint(t, s);
  const [path] = getStraightPath({ sourceX: a.x, sourceY: a.y, targetX: b.x, targetY: b.y });

  return (
    <g
      className="dissertation-contra-edge"
      onClick={(e) => open?.(data.cid, { x: e.clientX, top: e.clientY, bottom: e.clientY })}
    >
      <BaseEdge id={id} path={path} style={style} interactionWidth={28} />
    </g>
  );
}

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import "./contradiction.css";
import { ContradictionContext } from "./context";
import { EDGE_Z_INDEX, DEF_Z_INDEX } from "../01-definition/lib/placement";
import { rectAnchor } from "./lib/anchor";
import { describe as describeNode } from "./lib/describe";
import ContradictionBubble from "./components/ContradictionBubble";

const nodeId = (cid) => `contra-${cid}`;
const LINKABLE = new Set(["definition", "reformulation", "contradiction"]);
const CONTRA_STYLE = { stroke: "var(--contradiction)", strokeWidth: 2.5 };
const NODE_W = 220; // taille approximative du nœud d'intersection (flow units)
const NODE_H = 90;

let uid = 0;
const newId = () => `c${Date.now().toString(36)}${(uid++).toString(36)}`;

const hasText = (c) => c.text.trim() !== "";
// Le nœud d'intersection existe s'il y a un commentaire, ou si une autre contradiction s'y rattache.
const hasNode = (c, list) => hasText(c) || list.some((o) => o.a === nodeId(c.id) || o.b === nodeId(c.id));

const edge = (suffix, source, target, cid) => ({
  id: `contra:${cid}:${suffix}`,
  type: "contradiction",
  source,
  target,
  data: { cid },
  style: CONTRA_STYLE,
  zIndex: EDGE_Z_INDEX,
  deletable: false, // géré par l'étape (bouton « Supprimer le lien »)
});

const center = (n) => ({
  x: n.position.x + (n.measured?.width ?? NODE_W) / 2,
  y: n.position.y + (n.measured?.height ?? NODE_H) / 2,
});

/** Milieu entre deux nœuds (coin haut-gauche d'un nœud d'intersection qui y serait centré). */
function midpoint(a, b) {
  if (!a || !b) return { x: 0, y: 0 };
  const ca = center(a);
  const cb = center(b);
  return { x: (ca.x + cb.x) / 2 - NODE_W / 2, y: (ca.y + cb.y) / 2 - NODE_H / 2 };
}

const CLASSES = ["is-contradiction", "is-link-source"];

/**
 * Provider de l'étape : possède les contradictions { [id]: { id, a, b, text } } et les reflète
 * sur le canevas.
 *  - sans commentaire : un simple lien rouge a → b ;
 *  - avec commentaire : un nœud d'intersection relié à a et à b (liens rouges).
 * Un nœud d'intersection peut lui-même être relié à un autre nœud ou à une autre contradiction.
 * Création : clic sur deux nœuds (le premier est mis en surbrillance, Échap ou clic dans le vide annule).
 * Édition : clic sur un lien, ou sur le crayon qui apparaît au clic sur un nœud d'intersection.
 */
export default function ContradictionProvider({ status, canvas, children }) {
  const [contradictions, setContradictions] = useState({});
  const [bubble, setBubble] = useState(null); // { cid, anchor }
  const [picked, setPicked] = useState(null); // id du premier nœud choisi
  const enabled = status !== "locked";
  const editable = status === "current";
  const pickedId = editable ? picked : null;

  const ref = useRef(contradictions);
  ref.current = contradictions;

  const open = useCallback((cid, anchor) => {
    setPicked(null);
    setBubble({ cid, anchor });
  }, []);
  const close = useCallback(() => setBubble(null), []);

  /* ---------- Canevas : nœuds d'intersection et liens ---------- */

  // Clé de structure : le canevas n'est resynchronisé que si les liens ou les nœuds changent (pas à chaque frappe).
  const structure = useMemo(() => {
    const list = Object.values(contradictions);
    return list.map((c) => `${c.id}|${c.a}|${c.b}|${hasNode(c, list) ? 1 : 0}`).join(";");
  }, [contradictions]);

  useEffect(() => {
    const list = Object.values(ref.current);
    const withNode = list.filter((c) => hasNode(c, list));
    const wanted = new Map(withNode.map((c) => [nodeId(c.id), c]));
    const edges = list.flatMap((c) =>
      wanted.has(nodeId(c.id))
        ? [edge("a", c.a, nodeId(c.id), c.id), edge("b", c.b, nodeId(c.id), c.id)]
        : [edge("ab", c.a, c.b, c.id)]
    );

    canvas.setNodes((ns) => {
      const byId = new Map(ns.map((n) => [n.id, n]));
      const kept = ns.filter((n) => n.type !== "contradiction" || wanted.has(n.id));
      const added = [...wanted.values()]
        .filter((c) => !byId.has(nodeId(c.id)))
        .map((c) => ({
          id: nodeId(c.id),
          type: "contradiction",
          zIndex: DEF_Z_INDEX,
          deletable: false,
          position: midpoint(byId.get(c.a), byId.get(c.b)),
          data: { cid: c.id },
        }));
      return added.length || kept.length !== ns.length ? [...kept, ...added] : ns;
    });

    canvas.setEdges((es) => {
      const old = es.filter((e) => e.data?.cid);
      if (!old.length && !edges.length) return es;
      return [...es.filter((e) => !e.data?.cid), ...edges];
    });
  }, [structure, canvas]);

  // Nœuds rouges (reliés par une contradiction) et nœud de départ en cours de liaison.
  useEffect(() => {
    const red = new Set();
    for (const c of Object.values(ref.current)) {
      red.add(c.a);
      red.add(c.b);
    }
    canvas.setNodes((ns) => {
      let changed = false;
      const out = ns.map((n) => {
        const want = [red.has(n.id) && CLASSES[0], n.id === pickedId && CLASSES[1]].filter(Boolean);
        const rest = (n.className ?? "").split(/\s+/).filter((c) => c && !CLASSES.includes(c));
        const next = [...rest, ...want].join(" ");
        if (next === (n.className ?? "")) return n;
        changed = true;
        return { ...n, className: next || undefined };
      });
      return changed ? out : ns;
    });
  }, [structure, pickedId, canvas]);

  /* ---------- Création : clic sur deux nœuds ---------- */

  useEffect(() => {
    if (!editable) return;
    let down = null;
    const onDown = (e) => {
      down = { x: e.clientX, y: e.clientY };
    };
    const onClick = (e) => {
      if (e.target.closest?.(".nodrag")) return; // boutons internes (crayon, « Voir plus », pastilles)
      if (down && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 5) return; // glissement

      const el = e.target.closest?.(".react-flow__node");
      if (!el) {
        if (e.target.closest?.(".react-flow__pane")) setPicked(null); // clic dans le vide : annule
        return;
      }

      const id = el.dataset.id;
      const node = canvas.getNodes().find((n) => n.id === id);
      if (!node || !LINKABLE.has(node.type)) return;
      if (!picked) return setPicked(id);
      if (picked === id) return setPicked(null);

      const anchor = rectAnchor(el);
      const existing = Object.values(ref.current).find(
        (c) => (c.a === picked && c.b === id) || (c.a === id && c.b === picked)
      );
      setPicked(null);
      if (existing) return setBubble({ cid: existing.id, anchor });

      const cid = newId();
      setContradictions((cs) => ({ ...cs, [cid]: { id: cid, a: picked, b: id, text: "" } }));
      setBubble({ cid, anchor });
    };
    const onKey = (e) => e.key === "Escape" && setPicked(null);
    window.addEventListener("pointerdown", onDown, true);
    window.addEventListener("click", onClick, true);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("pointerdown", onDown, true);
      window.removeEventListener("click", onClick, true);
      window.removeEventListener("keydown", onKey);
    };
  }, [editable, picked, canvas]);

  /* ---------- Édition ---------- */

  const change = useCallback((cid, text) => {
    setContradictions((cs) => (cs[cid] ? { ...cs, [cid]: { ...cs[cid], text } } : cs));
  }, []);

  /** Supprime une contradiction, ainsi que celles qui sont reliées à son nœud d'intersection. */
  const remove = useCallback((cid) => {
    setContradictions((cs) => {
      const out = { ...cs };
      const stack = [cid];
      while (stack.length) {
        const id = stack.pop();
        delete out[id];
        for (const c of Object.values(out)) if (c.a === nodeId(id) || c.b === nodeId(id)) stack.push(c.id);
      }
      return out;
    });
    setBubble(null);
  }, []);

  /** Libellé et texte d'un nœud relié, pour la bulle (partagé avec l'étape « Problématique »). */
  const describe = (id) => describeNode(id, canvas.getNodes(), contradictions);

  const value = useMemo(
    () => ({ contradictions, open: enabled ? open : null }),
    [contradictions, enabled, open]
  );

  const current = bubble ? contradictions[bubble.cid] : null;

  return (
    <ContradictionContext.Provider value={value}>
      {children}

      {editable && (
        <div className="dissertation-linkbar">
          <p className="dissertation-linkhint">
            {picked ? "Cliquez sur le second nœud." : "Cliquez sur deux nœuds pour créer une contradiction."}
          </p>
        </div>
      )}

      {enabled && current && (
        <ContradictionBubble
          key={current.id}
          ends={[describe(current.a), describe(current.b)]}
          anchor={bubble.anchor}
          text={current.text}
          readOnly={!editable}
          onChange={(text) => change(current.id, text)}
          onDelete={() => remove(current.id)}
          onClose={close}
        />
      )}
    </ContradictionContext.Provider>
  );
}
import Provider from "./ContradictionProvider";
import ContradictionNode from "./components/ContradictionNode";
import ContradictionEdge from "./components/ContradictionEdge";

export default {
  id: "contradictions",
  title: "Identification des contradictions",
  description: "Cliquez sur deux nœuds pour les relier, puis commentez le lien.",
  order: 30,
  Provider,
  nodeTypes: { contradiction: ContradictionNode },
  edgeTypes: { contradiction: ContradictionEdge },
  // Au moins un lien rouge (avec ou sans commentaire).
  validate: ({ edges }) =>
    edges.some((e) => e.data?.cid)
      ? null
      : "Reliez au moins deux éléments contradictoires pour passer à l'étape suivante.",
};
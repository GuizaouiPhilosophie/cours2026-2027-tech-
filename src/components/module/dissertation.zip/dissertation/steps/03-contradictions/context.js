import { createContext, useContext } from "react";

/**
 * État de l'étape « Contradictions ».
 *   contradictions : { [id]: { id, a, b, text } }  (a et b = ids de nœuds React Flow ;
 *                    un nœud de contradiction a pour id `contra-<id>` et peut lui-même être relié)
 *   open           : (id, ancre) => void ; null tant que l'étape est verrouillée
 */
export const ContradictionContext = createContext({ contradictions: {}, open: null });
export const useContradictions = () => useContext(ContradictionContext);

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import "../04-problematique/problematique.css"; // mise en page « .is-workspace » de la bulle
import "./plan.css";
import { PlanContext } from "./context";
import { useKnowledge } from "../05-connaissances/context";
import { EDGE_STYLE, DEF_Z_INDEX, EDGE_Z_INDEX } from "../01-definition/lib/placement";
import { PARTS, partById, planNodeId, emptyPart, isStarted, isComplete } from "./lib/parts";
import PlanBubble from "./components/PlanBubble";

const THESIS_ID = "these";
const NODE_W = 260;
const GAP = 40;
const DROP = 160; // distance sous la thèse (flow units)

const initialParts = () => Object.fromEntries(PARTS.map((p) => [p.id, emptyPart()]));

/**
 * Provider de l'étape : possède les trois parties du plan et la bulle, et les reflète sur le canevas
 * (trois nœuds côte à côte sous la thèse, reliés à elle ; un nœud apparaît dès qu'un champ est rempli).
 * Ouverture : clic sur le nœud de thèse (première partie incomplète) ou sur le nœud d'une partie.
 */
export default function PlanProvider({ subject, status, canvas, children }) {
  const { items } = useKnowledge();
  const [parts, setParts] = useState(initialParts);
  const [bubble, setBubble] = useState(null); // { anchor, part }
  const enabled = status === "current";

  const partsRef = useRef(parts);
  partsRef.current = parts;

  const open = useCallback((partId, el) => {
    const r = el.getBoundingClientRect();
    const first = PARTS.find((p) => !isComplete(p, partsRef.current[p.id]))?.id ?? PARTS[0].id;
    setBubble({ anchor: { x: r.left + r.width / 2, top: r.top, bottom: r.bottom }, part: partId ?? first });
  }, []);
  const close = useCallback(() => setBubble(null), []);
  const selectPart = useCallback((part) => setBubble((b) => (b ? { ...b, part } : b)), []);

  // Clic sur la thèse (sans glissement : le nœud reste déplaçable).
  useEffect(() => {
    if (!enabled) return;
    let start = null;
    const thesisEl = (e) => e.target.closest?.(".dissertation-thesisnode");
    const down = (e) => {
      start = thesisEl(e) ? { x: e.clientX, y: e.clientY } : null;
    };
    const click = (e) => {
      const el = thesisEl(e);
      if (!el || !start) return;
      if (Math.hypot(e.clientX - start.x, e.clientY - start.y) > 5) return;
      open(null, el);
    };
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("click", click, true);
    return () => {
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("click", click, true);
    };
  }, [enabled, open]);

  /** Reflète une partie sur le canevas : crée, met à jour ou retire son nœud. */
  const sync = useCallback(
    (partId, values) => {
      const part = partById[partId];
      const id = planNodeId(partId);
      const data = { part: partId, ...values };

      if (!isStarted(part, values)) {
        canvas.setNodes((ns) => ns.filter((n) => n.id !== id));
        canvas.setEdges((es) => es.filter((e) => e.id !== id));
        return;
      }

      const ns = canvas.getNodes();
      if (ns.some((n) => n.id === id)) {
        canvas.setNodes((list) => list.map((n) => (n.id === id ? { ...n, data } : n)));
        return;
      }

      // Trois colonnes sous la thèse : I à gauche, II au centre, III à droite.
      const thesis = ns.find((n) => n.id === THESIS_ID);
      const cx = (thesis?.position.x ?? 0) + (thesis?.measured?.width ?? 300) / 2;
      const y = (thesis?.position.y ?? 0) + (thesis?.measured?.height ?? 120) + DROP;
      const index = PARTS.findIndex((p) => p.id === partId);
      const x = cx + (index - 1) * (NODE_W + GAP) - NODE_W / 2;

      canvas.setNodes((list) => [
        ...list,
        { id, type: "plan", zIndex: DEF_Z_INDEX, position: { x, y }, data },
      ]);
      canvas.setEdges((es) => [
        ...es,
        {
          id,
          source: id,
          sourceHandle: "out-top", // côtés ajustés ensuite par le nœud (facingNodeSide)
          target: THESIS_ID,
          targetHandle: "bottom",
          style: EDGE_STYLE,
          zIndex: EDGE_Z_INDEX,
        },
      ]);
    },
    [canvas]
  );

  /** Modifie une partie (champ ou connaissances) et met le canevas à jour. */
  const update = useCallback(
    (partId, patch) => {
      const values = { ...partsRef.current[partId], ...patch };
      partsRef.current = { ...partsRef.current, [partId]: values };
      setParts(partsRef.current);
      sync(partId, values);
    },
    [sync]
  );

  const toggleKnowledge = useCallback(
    (partId, kid) => {
      const list = partsRef.current[partId].knowledge;
      update(partId, { knowledge: list.includes(kid) ? list.filter((k) => k !== kid) : [...list, kid] });
    },
    [update]
  );

  const value = useMemo(() => ({ open: enabled ? open : null }), [enabled, open]);

  return (
    <PlanContext.Provider value={value}>
      {children}

      {enabled && !bubble && (
        <div className="dissertation-planbar">
          <p className="dissertation-planhint">Cliquez sur la thèse pour construire votre plan.</p>
        </div>
      )}

      {enabled && bubble && (
        <PlanBubble
          subject={subject}
          anchor={bubble.anchor}
          part={bubble.part}
          parts={parts}
          knowledge={items}
          nodes={canvas.getNodes()}
          onSelectPart={selectPart}
          onChange={(key, text) => update(bubble.part, { [key]: text })}
          onToggleKnowledge={(kid) => toggleKnowledge(bubble.part, kid)}
          onClose={close}
        />
      )}
    </PlanContext.Provider>
  );
}

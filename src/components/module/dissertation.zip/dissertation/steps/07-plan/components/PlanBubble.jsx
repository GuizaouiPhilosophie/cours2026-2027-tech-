import { useEffect, useMemo, useRef } from "react";
import useEscape from "../../../lib/useEscape";
import useSheetViewport from "../../../lib/useSheetViewport";
import { PARTS, partById, isComplete } from "../lib/parts";
import KnowledgePicker from "./KnowledgePicker";

const MAX_W = 820;
const NARROW = 640;
const COMPACT_H = 560; // clavier ouvert / petit téléphone : on ne garde que la thèse comme repère
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

/** Grand écran : bulle sous (ou au-dessus) du nœud cliqué. Petit écran : plein écran. */
function place(anchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (!anchor || vw < NARROW) return { sheet: true, style: {} };

  const width = Math.min(MAX_W, vw - 16);
  const left = clamp(anchor.x - width / 2, 8, vw - width - 8);
  const arrow = clamp(anchor.x - left, 24, width - 24);
  const room = vh - anchor.bottom;

  return room >= 460 || room >= anchor.top
    ? { side: "below", arrow, style: { left, width, top: anchor.bottom + 12, maxHeight: room - 20 } }
    : { side: "above", arrow, style: { left, width, bottom: vh - anchor.top + 12, maxHeight: anchor.top - 20 } };
}

/**
 * Bulle du plan dialectique, même mise en page que la problématique et la thèse (.is-workspace).
 *  - à gauche : sujet, problématique, thèse, puis les connaissances à mobiliser dans la partie affichée ;
 *  - à droite : onglets I / II / III, consigne de la partie et ses deux champs.
 * Mobile : plein écran vertical, sans défilement vertical.
 */
export default function PlanBubble({
  subject, anchor, part, parts, knowledge, nodes, onSelectPart, onChange, onToggleKnowledge, onClose,
}) {
  const ref = useRef(null);
  const pos = useMemo(() => place(anchor), [anchor]);
  const sheet = useSheetViewport(pos.sheet);
  const compact = sheet.height !== null && sheet.height < COMPACT_H;
  const current = partById[part];
  const values = parts[part];
  const textOf = (id) => nodes.find((n) => n.id === id)?.data?.text ?? "";

  useEscape(onClose);

  useEffect(() => {
    const onDown = (e) => {
      if (ref.current?.contains(e.target)) return;
      if (e.target.closest?.(".dissertation-thesisnode, .dissertation-plannode")) return; // ils (ré)ouvrent la bulle
      onClose();
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [onClose]);

  const style = pos.sheet ? sheet.style : { ...pos.style, "--arrow-x": `${pos.arrow}px` };

  return (
    <div
      ref={ref}
      className={`dissertation-bubble is-workspace is-plan ${pos.sheet ? "is-sheet" : `is-${pos.side}`}${compact ? " is-compact" : ""}`}
      style={style}
      role="dialog"
      aria-label="Plan dialectique"
    >
      <div className="dissertation-bubble-body">
        <div className="dissertation-bubble-head">
          <h2>Plan dialectique</h2>
          <button type="button" className="dissertation-close" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>

        <div className="dissertation-problem-layout">
          <div className="dissertation-problem-sources">
            <div className="dissertation-problem-block dissertation-plan-subject">
              <span>Sujet</span>
              <p className="dissertation-plan-ref is-subject">{subject}</p>
            </div>
            <div className="dissertation-problem-block dissertation-plan-problem">
              <span>Problématique</span>
              <p className="dissertation-plan-ref">{textOf("problematique")}</p>
            </div>
            <div className="dissertation-problem-block">
              <span>Thèse</span>
              <p className="dissertation-plan-ref is-thesis">{textOf("these")}</p>
            </div>
            <div className="dissertation-problem-block dissertation-plan-knowledge">
              <span>Connaissances : touchez pour les mobiliser en {current.num}</span>
              <KnowledgePicker knowledge={knowledge} parts={parts} current={part} onToggle={onToggleKnowledge} />
            </div>
          </div>

          <div className="dissertation-problem-write dissertation-plan-editor">
            <div className="dissertation-plan-tabs" role="tablist" aria-label="Parties du plan">
              {PARTS.map((p) => {
                const done = isComplete(p, parts[p.id]);
                return (
                  <button
                    key={p.id}
                    type="button"
                    role="tab"
                    aria-selected={p.id === part}
                    className={`dissertation-plan-tab${p.id === part ? " is-active" : ""}${done ? " is-done" : ""}`}
                    onClick={() => onSelectPart(p.id)}
                  >
                    <span className="dissertation-plan-tab-num">{done ? "✓" : p.num}</span>
                    {p.title}
                  </button>
                );
              })}
            </div>

            <p className="dissertation-plan-goal">{current.goal}</p>

            {current.fields.map((f, i) => (
              <label key={`${part}-${f.key}`} className="dissertation-field dissertation-plan-field">
                <span>{f.label}</span>
                <textarea
                  autoFocus={!pos.sheet && i === 0}
                  value={values[f.key]}
                  placeholder={f.placeholder}
                  onChange={(e) => onChange(f.key, e.target.value)}
                />
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

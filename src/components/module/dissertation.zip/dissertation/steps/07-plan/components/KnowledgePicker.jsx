import { PARTS } from "../lib/parts";

/**
 * Connaissances de l'étape 5, en cartes : un clic mobilise (ou retire) la connaissance
 * dans la partie affichée. Chaque carte indique les parties qui l'utilisent déjà.
 */
export default function KnowledgePicker({ knowledge, parts, current, onToggle }) {
  const list = Object.values(knowledge).filter((k) => k.text.trim());
  if (list.length === 0) return <p className="dissertation-tools-empty">Aucune connaissance.</p>;

  return (
    <ul className="dissertation-problem-row">
      {list.map((k) => {
        const on = parts[current].knowledge.includes(k.id);
        const usedIn = PARTS.filter((p) => parts[p.id].knowledge.includes(k.id));
        return (
          <li key={k.id} className="dissertation-plan-knowitem">
            <button
              type="button"
              className={`dissertation-problem-card is-know dissertation-plan-know${on ? " is-on" : ""}`}
              aria-pressed={on}
              onClick={() => onToggle(k.id)}
            >
              <p>{k.text}</p>
              <span className="dissertation-plan-used">
                {usedIn.length === 0
                  ? "Non mobilisée"
                  : usedIn.map((p) => (
                      <span key={p.id} className={`dissertation-plan-badge${p.id === current ? " is-current" : ""}`}>
                        {p.num}
                      </span>
                    ))}
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

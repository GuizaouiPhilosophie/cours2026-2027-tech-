import { useEffect } from "react";
import { Handle, useInternalNode, useReactFlow } from "@xyflow/react";
import { usePlan } from "../context";
import { partById, isComplete } from "../lib/parts";
import { SIDES, OPPOSITE, POSITION, childHandle, facingNodeSide } from "../../01-definition/lib/placement";

const THESIS_ID = "these";

/**
 * Nœud d'une partie du plan (I, II ou III), relié à la thèse.
 * Affiche l'idée directrice, la limite (ou la réponse au sujet pour la III) et le nombre de connaissances mobilisées.
 */
export default function PlanNode({ id, data }) {
  const { open } = usePlan();
  const { setEdges } = useReactFlow();
  const self = useInternalNode(id);
  const thesis = useInternalNode(THESIS_ID);
  const part = partById[data.part];

  const side = facingNodeSide(self, thesis); // côté de la THÈSE qui fait face à ce nœud

  useEffect(() => {
    if (!side) return;
    const sourceHandle = childHandle(OPPOSITE[side]);
    const targetHandle = side;
    setEdges((es) =>
      es.some((e) => e.id === id && (e.sourceHandle !== sourceHandle || e.targetHandle !== targetHandle))
        ? es.map((e) => (e.id === id ? { ...e, sourceHandle, targetHandle } : e))
        : es
    );
  }, [side, id, setEdges]);

  if (!part) return null;
  const [first, second] = part.fields;
  const count = data.knowledge?.length ?? 0;
  const done = isComplete(part, data);

  const go = (e) => open?.(part.id, e.currentTarget);
  return (
    <div
      className={`dissertation-plannode${done ? " is-done" : ""}`}
      role={open ? "button" : undefined}
      tabIndex={open ? 0 : undefined}
      title={open ? `Modifier la partie ${part.num}` : undefined}
      onClick={open ? go : undefined}
      onKeyDown={open ? (e) => (e.key === "Enter" || e.key === " ") && go(e) : undefined}
    >
      {SIDES.map((s) => (
        <Handle key={`in-${s}`} id={s} type="target" position={POSITION[s]} isConnectable={false} className="dissertation-handle" />
      ))}
      {SIDES.map((s) => (
        <Handle
          key={s}
          id={childHandle(s)}
          type="source"
          position={POSITION[s]}
          isConnectable={false}
          className="dissertation-handle"
        />
      ))}
      <span className="dissertation-plannode-label">
        {part.num}. {part.title}
      </span>
      {data[first.key]?.trim() && <p>{data[first.key]}</p>}
      {data[second.key]?.trim() && (
        <p className="dissertation-plannode-second">
          <em>{part.id === "depassement" ? "Réponse : " : "Limite : "}</em>
          {data[second.key]}
        </p>
      )}
      {count > 0 && (
        <span className="dissertation-plannode-count">
          {count} connaissance{count > 1 ? "s" : ""}
        </span>
      )}
    </div>
  );
}

import Provider from "./PlanProvider";
import PlanNode from "./components/PlanNode";
import { PARTS, planNodeId } from "./lib/parts";

export default {
  id: "plan",
  title: "Plan dialectique",
  description: "Cliquez sur la thèse pour construire les trois parties du plan.",
  order: 70,
  Provider,
  nodeTypes: { plan: PlanNode },
  // Les deux champs de chaque partie doivent être remplis.
  validate: ({ nodes }) => {
    for (const part of PARTS) {
      const data = nodes.find((n) => n.id === planNodeId(part.id))?.data;
      for (const f of part.fields) {
        if (!data?.[f.key]?.trim()) return `Partie ${part.num} (${part.title}) : complétez « ${f.label} ».`;
      }
    }
    return null;
  },
};

import { createContext, useContext } from "react";

/** open : (idPartie, élément) => void ; null tant que l'étape n'est pas l'étape courante. */
export const PlanContext = createContext({ open: null });
export const usePlan = () => useContext(PlanContext);

import { createContext, useContext } from "react";

/** open : (élément) => void ; null tant que l'étape est verrouillée. */
export const ReformulationContext = createContext({ open: null });
export const useReformulation = () => useContext(ReformulationContext);
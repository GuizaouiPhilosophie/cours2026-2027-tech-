import { useEffect, useMemo, useRef, useState } from "react";
import { byId, tokenize } from "../../01-definition/lib/definitions";
import useEscape from "../../../lib/useEscape";
import useSheetViewport from "../../../lib/useSheetViewport";

const WIDTH = 460;
const NARROW = 640;
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

/** Même placement que DefinitionBubble ; « feuille » en haut sur petit écran. */
function place(anchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (!anchor || vw < NARROW) return { sheet: true, style: {} };

  const left = clamp(anchor.x - WIDTH / 2, 8, vw - WIDTH - 8);
  const arrow = clamp(anchor.x - left, 24, WIDTH - 24);
  const room = vh - anchor.bottom;

  return room >= 360 || room >= anchor.top
    ? { side: "below", arrow, style: { left, top: anchor.bottom + 12, maxHeight: room - 20 } }
    : { side: "above", arrow, style: { left, bottom: vh - anchor.top + 12, maxHeight: anchor.top - 20 } };
}

/**
 * Bulle de reformulation : sujet d'origine, mots définis (tags → leurs définitions,
 * avec les définitions liées), puis zone d'écriture enregistrée à chaque frappe.
 */
export default function ReformulationBubble({
  subject, anchor, definitions, linked, text, readOnly, onChange, onClose,
}) {
  const ref = useRef(null);
  const [openKey, setOpenKey] = useState(null);
  const pos = useMemo(() => place(anchor), [anchor]);
  const sheet = useSheetViewport(pos.sheet); // petit écran : plein écran

  // Mots du sujet qui ont au moins une définition, dans l'ordre du sujet.
  const words = useMemo(() => {
    const seen = new Set();
    return tokenize(subject).filter((t) => {
      if (t.type !== "word" || seen.has(t.key) || !definitions[t.key]?.length) return false;
      seen.add(t.key);
      return true;
    });
  }, [subject, definitions]);

  // Nœuds créés depuis un concept associé, descendants d'un nœud de définition.
  const descendants = (id) =>
    linked.filter((n) => n.data.parent === id).flatMap((n) => [n, ...descendants(n.id)]);

  useEscape(onClose);

  useEffect(() => {
    const onDown = (e) => {
      if (ref.current?.contains(e.target)) return;
      if (e.target.closest?.(".dissertation-subject-node, .dissertation-reformnode")) return; // ils (ré)ouvrent la bulle
      onClose();
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className={`dissertation-bubble is-reform ${pos.sheet ? "is-sheet" : `is-${pos.side}`}`}
      style={{ ...pos.style, ...sheet.style, "--arrow-x": `${pos.arrow ?? 0}px` }}
      role="dialog"
      aria-label="Reformulation du sujet"
    >
      <div className="dissertation-bubble-body">
        <div className="dissertation-bubble-head">
          <h2>Reformulation</h2>
          <button type="button" className="dissertation-close" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>

        <div className="dissertation-reform-block">
          <span>Sujet d'origine</span>
          <p className="dissertation-reform-subject">{subject}</p>
        </div>

        <div className="dissertation-reform-block">
          <span>Vos définitions</span>
          {words.length === 0 ? (
            <p className="dissertation-tools-empty">Aucune définition rédigée.</p>
          ) : (
            <div className="dissertation-chips">
              {words.map((w) => (
                <button
                  key={w.key}
                  type="button"
                  className={`dissertation-chip${openKey === w.key ? " is-active" : ""}`}
                  aria-expanded={openKey === w.key}
                  onClick={() => setOpenKey((k) => (k === w.key ? null : w.key))}
                >
                  {w.text}
                  {definitions[w.key].length > 1 ? ` (${definitions[w.key].length})` : ""}
                </button>
              ))}
            </div>
          )}

          {openKey && definitions[openKey] && (
            <ul className="dissertation-reform-defs">
              {definitions[openKey].map((d) => {
                const src = d.source ? byId.get(d.source) : null;
                const related = descendants(`def-${openKey}-${d.id}`);
                return (
                  <li key={d.id} className="dissertation-reform-def">
                    {src && <span className="dissertation-reform-src">Glossaire : {src.terme}</span>}
                    <p>{d.text}</p>
                    {related.length > 0 && (
                      <div className="dissertation-reform-linked">
                        <span>Définitions liées</span>
                        {related.map((n) => (
                          <div key={n.id}>
                            <strong>{n.data.word}</strong>
                            <p>{n.data.text}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <label className="dissertation-field dissertation-field-grow">
          <span>Votre reformulation</span>
          <textarea
            autoFocus
            rows={8}
            value={text}
            readOnly={readOnly}
            placeholder="Reformulez le sujet avec vos propres mots…"
            onChange={(e) => onChange(e.target.value)}
          />
        </label>
      </div>
    </div>
  );
}
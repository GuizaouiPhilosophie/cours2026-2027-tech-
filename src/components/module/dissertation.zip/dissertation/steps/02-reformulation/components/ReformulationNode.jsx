import { useEffect } from "react";
import { Handle, useInternalNode, useReactFlow } from "@xyflow/react";
import { useReformulation } from "../context";
import { SIDES, OPPOSITE, POSITION, childHandle, facingNodeSide } from "../../01-definition/lib/placement";

/**
 * Nœud de la carte mentale : la reformulation du sujet, reliée à celui-ci.
 * Comme les nœuds de définition, il peut être déplacé tout autour du sujet : le lien part
 * du côté du nœud qui regarde le sujet et arrive sur le côté du sujet qui regarde le nœud
 * (poignées `in-<côté>` déclarées par SubjectNode dans DissertationEditor.jsx).
 */
export default function ReformulationNode({ id, data }) {
  const { open } = useReformulation();
  const { setEdges } = useReactFlow();
  const self = useInternalNode(id);
  const subject = useInternalNode("subject");

  // Côté du SUJET qui fait face à ce nœud ; null tant que les deux nœuds ne sont pas mesurés.
  const side = facingNodeSide(self, subject);

  useEffect(() => {
    if (!side) return;
    const sourceHandle = childHandle(OPPOSITE[side]); // côté de ce nœud tourné vers le sujet
    const targetHandle = `in-${side}`;
    setEdges((es) =>
      es.some((e) => e.id === id && (e.sourceHandle !== sourceHandle || e.targetHandle !== targetHandle))
        ? es.map((e) => (e.id === id ? { ...e, sourceHandle, targetHandle } : e))
        : es
    );
  }, [side, id, setEdges]);

  const go = (e) => open?.(e.currentTarget);
  return (
    <div
      className="dissertation-reformnode"
      role={open ? "button" : undefined}
      tabIndex={open ? 0 : undefined}
      title={open ? "Voir la reformulation" : undefined}
      onClick={open ? go : undefined}
      onKeyDown={open ? (e) => (e.key === "Enter" || e.key === " ") && go(e) : undefined}
    >
      {/* Poignées d'arrivée : la reformulation peut aussi être reliée par une contradiction (étape 3). */}
      {SIDES.map((s) => (
        <Handle key={`in-${s}`} id={s} type="target" position={POSITION[s]} isConnectable={false} className="dissertation-handle" />
      ))}
      {SIDES.map((s) => (
        <Handle
          key={s}
          id={childHandle(s)}
          type="source"
          position={POSITION[s]}
          isConnectable={false}
          className="dissertation-handle"
        />
      ))}
      <span className="dissertation-reformnode-label">Reformulation</span>
      <p>{data.text}</p>
    </div>
  );
}
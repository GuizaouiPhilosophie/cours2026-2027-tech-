import Provider from "./ReformulationProvider";
import ReformulationNode from "./components/ReformulationNode";

export default {
  id: "reformulation",
  title: "Reformulation du sujet",
  description: "Cliquez sur le sujet pour le reformuler à partir de vos définitions.",
  order: 20,
  Provider,
  nodeTypes: { reformulation: ReformulationNode },
  validate: ({ nodes }) =>
    nodes.some((n) => n.type === "reformulation" && n.data?.text?.trim())
      ? null
      : "Rédigez votre reformulation pour passer à l'étape suivante.",
};
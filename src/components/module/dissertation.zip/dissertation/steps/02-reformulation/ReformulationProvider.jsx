import { useCallback, useEffect, useMemo, useState } from "react";
import "./reformulation.css";
import { ReformulationContext } from "./context";
import { useDefinitions } from "../01-definition/context";
import { EDGE_STYLE, DEF_Z_INDEX, EDGE_Z_INDEX } from "../01-definition/lib/placement";
import ReformulationBubble from "./components/ReformulationBubble";

const NODE_ID = "reformulation";
const RISE = 300; // distance au-dessus du sujet (flow units)

/**
 * Provider de l'étape : possède le texte de la reformulation et sa bulle, et le reflète
 * sur le canevas (un nœud au-dessus du sujet, relié à lui).
 * Il est rendu à l'intérieur du Provider « Définition » : il peut donc lire useDefinitions().
 * Ouverture : clic sur le nœud du sujet ou sur le nœud de reformulation.
 */
export default function ReformulationProvider({ subject, status, canvas, children }) {
  const { definitions } = useDefinitions();
  const [text, setText] = useState("");
  const [bubble, setBubble] = useState(null); // { anchor, linked }
  const enabled = status === "current"; // une fois l'étape validée, la reformulation n'est plus ouvrable

  const open = useCallback(
    (el) => {
      const r = el.getBoundingClientRect();
      // Nœuds créés depuis un concept associé : photographiés à l'ouverture.
      const linked = canvas.getNodes().filter((n) => n.type === "definition" && n.data?.parent);
      setBubble({ anchor: { x: r.left + r.width / 2, top: r.top, bottom: r.bottom }, linked });
    },
    [canvas]
  );
  const close = useCallback(() => setBubble(null), []);

  // Clic sur le sujet (sans glissement : le nœud reste déplaçable).
  useEffect(() => {
    if (!enabled) return;
    let start = null;
    const subjectEl = (e) => e.target.closest?.(".dissertation-subject-node");
    const down = (e) => {
      start = subjectEl(e) ? { x: e.clientX, y: e.clientY } : null;
    };
    const click = (e) => {
      const el = subjectEl(e);
      if (!el || !start || e.target.closest(".dissertation-addword")) return;
      if (Math.hypot(e.clientX - start.x, e.clientY - start.y) > 5) return;
      open(el);
    };
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("click", click, true);
    return () => {
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("click", click, true);
    };
  }, [enabled, open]);

  /** Enregistre la reformulation à chaque frappe ; un texte vide supprime le nœud. */
  const change = useCallback(
    (next) => {
      setText(next);

      if (!next.trim()) {
        canvas.setNodes((ns) => ns.filter((n) => n.id !== NODE_ID));
        canvas.setEdges((es) => es.filter((e) => e.id !== NODE_ID));
        return;
      }

      const existing = canvas.getNodes().some((n) => n.id === NODE_ID);
      if (existing) {
        canvas.setNodes((ns) => ns.map((n) => (n.id === NODE_ID ? { ...n, data: { ...n.data, text: next } } : n)));
        return;
      }

      const subj = canvas.getNodes().find((n) => n.id === "subject");
      const sx = (subj?.position.x ?? 0) + (subj?.measured?.width ?? 300) / 2;
      const sy = subj?.position.y ?? 0;
      canvas.setNodes((ns) => [
        ...ns,
        {
          id: NODE_ID,
          type: "reformulation",
          zIndex: DEF_Z_INDEX,
          position: { x: sx - 150, y: sy - RISE },
          data: { text: next },
        },
      ]);
      canvas.setEdges((es) => [
        ...es,
        {
          id: NODE_ID,
          source: NODE_ID,
          sourceHandle: "out-bottom", // côtés ajustés ensuite par le nœud (facingNodeSide)
          target: "subject",
          targetHandle: "in-top",
          style: EDGE_STYLE,
          zIndex: EDGE_Z_INDEX,
        },
      ]);
    },
    [canvas]
  );

  const value = useMemo(() => ({ open: enabled ? open : null }), [enabled, open]);

  return (
    <ReformulationContext.Provider value={value}>
      {children}
      {enabled && bubble && (
        <ReformulationBubble
          subject={subject}
          anchor={bubble.anchor}
          definitions={definitions}
          linked={bubble.linked}
          text={text}
          onChange={change}
          onClose={close}
        />
      )}
    </ReformulationContext.Provider>
  );
}
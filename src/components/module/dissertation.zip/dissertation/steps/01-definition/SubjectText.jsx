import { useEffect, useMemo, useState } from "react";
import { Handle, useNodeId, useUpdateNodeInternals } from "@xyflow/react";
import { tokenize } from "./lib/definitions";
import { useDefinitions } from "./context";
import { SIDES, POSITION, wordHandle } from "./lib/placement";

/**
 * Texte du sujet, mot par mot : cliquable pour définir. Chaque mot porte une poignée
 * invisible par côté (haut, droite, bas, gauche) d'où part le lien vers le nœud de chaque définition.
 * Un mot déjà défini affiche, au clic, un bouton « + définition » pour en ajouter une autre.
 */
export default function SubjectText({ text }) {
  const { definitions, openWord, editable } = useDefinitions();
  const nodeId = useNodeId();
  const updateInternals = useUpdateNodeInternals();
  const tokens = useMemo(() => tokenize(text), [text]);
  const [menu, setMenu] = useState(null); // index du mot dont le bouton « + » est affiché

  // Les poignées sont à l'intérieur du texte : les re-mesurer quand la mise en page change.
  useEffect(() => {
    updateInternals(nodeId);
    document.fonts?.ready.then(() => updateInternals(nodeId));
  }, [nodeId, updateInternals, tokens, editable]);

  // Ferme le bouton « + » en cliquant ailleurs.
  useEffect(() => {
    if (menu === null) return;
    const close = (e) => !e.target.closest?.(".dissertation-wordwrap") && setMenu(null);
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [menu]);

  const seen = new Set(); // un mot répété n'a qu'une poignée

  return (
    <>
      {/* <div> et non <p> : les <Handle> de React Flow rendent des <div>, interdits dans un <p>. */}
      <div role="paragraph" className="dissertation-subject-text">
        {tokens.map((t, i) => {
          if (t.type === "sep") return t.text;
          const first = !seen.has(t.key);
          seen.add(t.key);
          const defined = definitions[t.key]?.length > 0;
          return (
            <span key={i} className="dissertation-wordwrap">
              <button
                type="button"
                className={`dissertation-word nodrag nopan${defined ? " is-defined" : ""}${editable ? "" : " is-readonly"}`}
                onClick={(e) => {
                  if (!editable) return; // lecture seule : le clic sur le sujet ouvre la reformulation (autre Provider)
                  if (defined) setMenu(menu === i ? null : i);
                  else openWord(t.text, t.key, e.currentTarget);
                }}
              >
                {t.text}
              </button>
              {menu === i && (
                <button
                  type="button"
                  className="dissertation-addword nodrag nopan"
                  onClick={(e) => {
                    const word = e.currentTarget.parentElement.querySelector(".dissertation-word");
                    setMenu(null);
                    openWord(t.text, t.key, word); // sans id : nouvelle définition
                  }}
                >
                  + définition
                </button>
              )}
              {first &&
                SIDES.map((side) => (
                  <Handle
                    key={side}
                    id={wordHandle(t.key, side)}
                    type="source"
                    position={POSITION[side]}
                    isConnectable={false}
                    className="dissertation-handle"
                  />
                ))}
            </span>
          );
        })}
      </div>
    </>
  );
}
import { useCallback, useMemo, useState } from "react";
import "./definition.css";
import { DefinitionContext } from "./context";
import DefinitionBubble from "./components/DefinitionBubble";
import { placeBelow, wordHandle, EDGE_STYLE, DEF_Z_INDEX, EDGE_Z_INDEX } from "./lib/placement";
import { newDefId } from "./lib/definitions";

/**
 * Provider de l'étape : possède les définitions rédigées et la bulle ouverte, et
 * les reflète sur le canevas (un nœud par définition, relié au mot du sujet).
 * Un mot peut avoir plusieurs définitions : { [mot]: [{ id, text, source? }] }.
 * `status` : "locked" | "current" | "done" ; `canvas` : API de l'éditeur.
 */
export default function DefinitionProvider({ status, canvas, children }) {
  const [definitions, setDefinitions] = useState({});
  const [bubble, setBubble] = useState(null); // { text, key, defId, anchor }
  const editable = status !== "done"; // après validation : lecture seule

  // Sans defId : nouvelle définition pour ce mot.
  const openWord = useCallback((text, key, el, defId) => {
    const r = el.getBoundingClientRect();
    setBubble({
      text,
      key,
      defId: defId ?? newDefId(),
      anchor: { x: r.left + r.width / 2, top: r.top, bottom: r.bottom },
    });
  }, []);

  const closeBubble = useCallback(() => setBubble(null), []);

  /** Enregistre une définition d'un mot et met à jour son nœud ; un texte vide la supprime. */
  const setDefinition = useCallback(
    ({ key, text: word, defId, anchor }, entry) => {
      const id = `def-${key}-${defId}`;
      const empty = !entry.text.trim();

      setDefinitions((d) => {
        const list = d[key] ?? [];
        const updated = empty
          ? list.filter((e) => e.id !== defId)
          : list.some((e) => e.id === defId)
            ? list.map((e) => (e.id === defId ? { ...e, ...entry } : e))
            : [...list, { id: defId, ...entry }];
        const next = { ...d };
        if (updated.length) next[key] = updated;
        else delete next[key];
        return next;
      });

      if (empty) {
        canvas.setNodes((ns) => ns.filter((n) => n.id !== id));
        canvas.setEdges((es) => es.filter((e) => e.id !== id));
        return;
      }

      const isNew = !canvas.getNodes().some((n) => n.id === id);
      const node = isNew
        ? {
            id,
            type: "definition",
            zIndex: DEF_Z_INDEX,
            position: placeBelow(canvas, anchor),
            data: { key, defId, word, text: entry.text, source: entry.source },
          }
        : null;

      canvas.setNodes((ns) =>
        ns.some((n) => n.id === id)
          ? ns.map((n) => (n.id === id ? { ...n, data: { ...n.data, text: entry.text, source: entry.source } } : n))
          : node
            ? [...ns, node]
            : ns
      );
      canvas.setEdges((es) =>
        es.some((e) => e.id === id)
          ? es
          : [
              ...es,
              {
                id,
                source: "subject",
                sourceHandle: wordHandle(key, "bottom"), // côté ajusté ensuite par le nœud (facingSide)
                target: id,
                targetHandle: "top",
                style: EDGE_STYLE,
                zIndex: EDGE_Z_INDEX,
              },
            ]
      );
    },
    [canvas]
  );

  const value = useMemo(
    () => ({ definitions, openWord, editable }),
    [definitions, openWord, editable]
  );

  return (
    <DefinitionContext.Provider value={value}>
      {children}
      {editable && bubble && (
        <DefinitionBubble
          key={`${bubble.key}-${bubble.defId}`}
          word={bubble.text}
          anchor={bubble.anchor}
          entry={definitions[bubble.key]?.find((e) => e.id === bubble.defId)}
          onChange={(entry) => setDefinition(bubble, entry)}
          onClose={closeBubble}
        />
      )}
    </DefinitionContext.Provider>
  );
}
import { useEffect, useState } from "react";
import { Handle, useInternalNode, useReactFlow, useStore } from "@xyflow/react";
import { useDefinitions } from "../context";
import { byId } from "../lib/definitions";
import TermLink from "./TermLink";
import {
  SIDES,
  OPPOSITE,
  POSITION,
  facingSide,
  facingNodeSide,
  wordHandle,
  childHandle,
  placeChild,
  EDGE_STYLE,
  DEF_Z_INDEX,
  EDGE_Z_INDEX,
} from "../lib/placement";

function Links({ label, ids, pickedId, onPick }) {
  if (!ids?.length) return null;
  return (
    <div className="dissertation-defnode-group">
      <span>{label}</span>
      <div className="dissertation-chips">
        {ids.map((id) => (
          <TermLink key={id} id={id} active={id === pickedId} onClick={onPick} />
        ))}
      </div>
    </div>
  );
}

/**
 * Nœud de la carte mentale : la définition rédigée d'un mot, reliée à ce mot.
 * Si elle vient du glossaire, affiche aussi les concepts associés et « voir aussi »
 * (définition au survol ou au clic). Ces liens sont masqués par défaut : « Voir plus » / « Réduire ».
 * Un clic sur une pastille affiche sa définition dans le nœud, avec un bouton pour la créer
 * comme nouveau nœud relié à celui-ci (`data.parent` = id du nœud parent ; ces nœuds ne sont pas modifiables).
 */
export default function DefinitionNode({ id, data }) {
  const { openWord, editable: stepEditable } = useDefinitions();
  const { setNodes, setEdges, getNodes } = useReactFlow();
  const self = useInternalNode(id);
  const subject = useInternalNode("subject");
  const parentId = data.parent ?? null;
  const parent = useInternalNode(parentId ?? "");

  // Côté d'où part le lien : celui du mot (nœud de mot) ou celui du nœud parent (nœud enfant).
  // Recalculé quand le nœud (ou son point de départ) bouge.
  const side = parentId ? facingNodeSide(self, parent) : facingSide(self, subject, data.key);

  useEffect(() => {
    if (!side) return;
    const sourceHandle = parentId ? childHandle(side) : wordHandle(data.key, side);
    const targetHandle = OPPOSITE[side];
    setEdges((es) =>
      es.some((e) => e.id === id && (e.sourceHandle !== sourceHandle || e.targetHandle !== targetHandle))
        ? es.map((e) => (e.id === id ? { ...e, sourceHandle, targetHandle } : e))
        : es
    );
  }, [side, id, parentId, data.key, setEdges]);

  const term = data.source ? byId.get(data.source) : null;
  const [expanded, setExpanded] = useState(false);
  const [pickedId, setPickedId] = useState(null); // pastille dont la définition est affichée
  const hasLinks = !!term && (term.associes?.length > 0 || term.voir_aussi?.length > 0);
  const editable = !parentId && stepEditable;
  const open = (e) => openWord?.(data.word, data.key, e.currentTarget, data.defId);

  const picked = pickedId ? byId.get(pickedId) : null;
  const childId = picked ? `term-${id}-${picked.id}` : "";
  const childExists = useStore((s) => !!childId && s.nodeLookup.has(childId));

  const pick = (termId) => setPickedId((cur) => (cur === termId ? null : termId));

  const createChild = () => {
    if (!picked || getNodes().some((n) => n.id === childId)) return;
    setNodes((ns) => [
      ...ns,
      {
        id: childId,
        type: "definition",
        zIndex: DEF_Z_INDEX,
        position: placeChild(ns, id),
        data: { key: data.key, word: picked.terme, text: picked.definition, source: picked.id, parent: id },
      },
    ]);
    setEdges((es) => [
      ...es,
      {
        id: childId,
        source: id,
        sourceHandle: childHandle("bottom"), // côté ajusté ensuite par le nœud enfant (facingNodeSide)
        target: childId,
        targetHandle: "top",
        style: EDGE_STYLE,
        zIndex: EDGE_Z_INDEX,
      },
    ]);
  };

  return (
    <div
      className={`dissertation-defnode${editable ? "" : " is-child"}`}
      role={editable ? "button" : undefined}
      tabIndex={editable ? 0 : undefined}
      title={editable ? "Modifier la définition" : undefined}
      onClick={editable ? open : undefined}
      onKeyDown={editable ? (e) => (e.key === "Enter" || e.key === " ") && open(e) : undefined}
    >
      {SIDES.map((s) => (
        <Handle key={s} id={s} type="target" position={POSITION[s]} className="dissertation-handle" />
      ))}
      {SIDES.map((s) => (
        <Handle
          key={`out-${s}`}
          id={childHandle(s)}
          type="source"
          position={POSITION[s]}
          isConnectable={false}
          className="dissertation-handle"
        />
      ))}
      <div className="dissertation-defnode-head">
        <strong>{data.word}</strong>
        {hasLinks && (
          // Ne doit ni rouvrir la bulle ni déplacer le nœud.
          <button
            type="button"
            className="dissertation-defnode-toggle nodrag nopan"
            aria-expanded={expanded}
            onClick={(e) => {
              e.stopPropagation();
              setExpanded((v) => !v);
              setPickedId(null);
            }}
            onKeyDown={(e) => e.stopPropagation()}
          >
            {expanded ? "Réduire" : "Voir plus"}
          </button>
        )}
      </div>
      <p>{data.text}</p>

      {hasLinks && expanded && (
        // Les pastilles ne doivent ni rouvrir la bulle ni déplacer le nœud.
        <div
          className="dissertation-defnode-links nodrag nopan"
          onClick={(e) => e.stopPropagation()}
          onKeyDown={(e) => e.stopPropagation()}
        >
          <Links label="Concepts associés" ids={term.associes} pickedId={pickedId} onPick={pick} />
          <Links label="Voir aussi" ids={term.voir_aussi} pickedId={pickedId} onPick={pick} />

          {picked && (
            <div className="dissertation-defnode-preview">
              <strong>{picked.terme}</strong>
              <p>{picked.definition}</p>
              <button
                type="button"
                className="dissertation-defnode-create"
                disabled={childExists || !stepEditable}
                onClick={createChild}
              >
                {childExists ? "Déjà sur la carte" : "Créer un nœud"}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
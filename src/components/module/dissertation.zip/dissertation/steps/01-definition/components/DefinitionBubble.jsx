import { useEffect, useMemo, useRef, useState } from "react";
import { byId, searchTerms, filterGlossary } from "../lib/definitions";
import useEscape from "../../../lib/useEscape";
import useSheetViewport from "../../../lib/useSheetViewport";
import Glossary from "./Glossary";

const WIDTH = 380;
const NARROW = 640;
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

// Hauteur de la liste du glossaire (px), réglable avec la barre de glissement.
const GLOSSARY_H = 130; // ≈ 1 entrée et demie : le 1er terme et un bout du 2e
const GLOSSARY_MIN = 80;
const GLOSSARY_STEP = 32;

/** Position de la bulle sous (ou au-dessus) du mot ; en « feuille » sur petit écran. */
function place(anchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (!anchor || vw < NARROW) return { sheet: true, style: {} };

  const left = clamp(anchor.x - WIDTH / 2, 8, vw - WIDTH - 8);
  const arrow = clamp(anchor.x - left, 24, WIDTH - 24);
  const room = vh - anchor.bottom;

  return room >= 320 || room >= anchor.top
    ? { side: "below", arrow, style: { left, top: anchor.bottom + 12, maxHeight: room - 20 } }
    : { side: "above", arrow, style: { left, bottom: vh - anchor.top + 12, maxHeight: anchor.top - 20 } };
}

/**
 * Bulle de définition d'un mot du sujet.
 * - la définition rédigée est enregistrée à chaque frappe (onChange) ;
 * - la recherche (vide au départ) propose des termes du glossaire ;
 * - cliquer un terme (glossaire ou recherche) l'applique directement et le met en surbrillance ;
 *   une confirmation n'est demandée que si le texte actuel est une définition personnelle.
 */
export default function DefinitionBubble({ word, anchor, entry, onChange, onClose }) {
  const ref = useRef(null);
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [showGlossary, setShowGlossary] = useState(false);
  const [pending, setPending] = useState(null); // terme en attente de confirmation
  const [glossaryH, setGlossaryH] = useState(GLOSSARY_H);
  const boxRef = useRef(null); // conteneur de la liste du glossaire
  const drag = useRef(null); // { y, h } au début du glissement

  const pos = useMemo(() => place(anchor), [anchor]);
  const sheet = useSheetViewport(pos.sheet); // petit écran : plein écran
  const text = entry?.text ?? "";
  // Terme du glossaire actuellement appliqué (surbrillance) ; plus rien si le texte a été modifié à la main.
  const source = entry?.source ? byId.get(entry.source) : null;
  const selectedId = source && source.definition === text ? source.id : null;
  // Définition personnelle : du texte qui n'est pas celle d'un terme du glossaire.
  const isCustom = text.trim() !== "" && selectedId === null;
  const results = useMemo(
    () => (showGlossary ? filterGlossary(query) : searchTerms(query)),
    [showGlossary, query]
  );

  useEscape(onClose);

  // Clic ailleurs : fermer (sauf sur un mot du sujet, qui rouvre une autre bulle).
  useEffect(() => {
    const onDown = (e) => {
      if (ref.current?.contains(e.target)) return;
      if (e.target.closest?.(".dissertation-word")) return;
      onClose();
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [onClose]);

  const apply = (term) => {
    setPending(null);
    onChange({ text: term.definition, source: term.id });
  };

  // Clic sur un terme : appliqué tout de suite, sauf s'il écraserait une définition personnelle.
  const select = (term) => {
    if (term.id === selectedId) return;
    if (isCustom) setPending(term);
    else apply(term);
  };

  // Hauteur actuellement affichée de la liste (peut être inférieure à celle demandée si la place manque).
  const shownHeight = () => boxRef.current?.offsetHeight ?? glossaryH;

  // Hauteur maximale possible : tout le reste de la bulle (champ, recherche, confirmation…) doit rester visible.
  // Mesure : on demande une hauteur énorme ; le navigateur la réduit à la place réellement disponible.
  const maxGlossary = () => {
    const box = boxRef.current;
    if (!box) return glossaryH;
    const prev = box.style.flexBasis;
    box.style.flexBasis = "9999px";
    const h = box.offsetHeight;
    box.style.flexBasis = prev;
    return h;
  };

  const resizeGlossary = (h) =>
    setGlossaryH(clamp(h, GLOSSARY_MIN, Math.max(maxGlossary(), GLOSSARY_MIN)));

  const gripDown = (e) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    drag.current = { y: e.clientY, h: shownHeight() };
  };
  const gripMove = (e) => {
    if (drag.current) resizeGlossary(drag.current.h + e.clientY - drag.current.y);
  };
  const gripEnd = () => {
    drag.current = null;
  };
  const gripKey = (e) => {
    if (e.key === "ArrowDown") resizeGlossary(shownHeight() + GLOSSARY_STEP);
    else if (e.key === "ArrowUp") resizeGlossary(shownHeight() - GLOSSARY_STEP);
    else return;
    e.preventDefault();
  };

  return (
    <div
      ref={ref}
      className={`dissertation-bubble ${pos.sheet ? "is-sheet" : `is-${pos.side}`}${showGlossary ? " has-glossary" : ""}`}
      style={{ ...pos.style, ...sheet.style, "--arrow-x": `${pos.arrow ?? 0}px` }}
      role="dialog"
      aria-label={`Définition de « ${word} »`}
    >
      <div className="dissertation-bubble-body">
        <div className="dissertation-bubble-head">
          <h2>{word}</h2>
          <button type="button" className="dissertation-close" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>

        {/* Plein écran (mobile) : le champ remplit la place libre, sauf quand le glossaire est ouvert */}
        <label className={`dissertation-field${showGlossary ? "" : " dissertation-field-grow"}`}>
          <span>Votre définition</span>
          <textarea
            autoFocus
            rows={4}
            value={text}
            placeholder="Rédigez votre définition…"
            onChange={(e) => onChange({ text: e.target.value, source: entry?.source })}
          />
        </label>

        <div className="dissertation-search">
          <input
            type="search"
            value={query}
            placeholder="Chercher dans le glossaire…"
            aria-label="Chercher dans le glossaire"
            onChange={(e) => {
              setQuery(e.target.value);
              setSearching(true);
            }}
          />
          <button
            type="button"
            className={`dissertation-tool${showGlossary ? " is-active" : ""}`}
            aria-pressed={showGlossary}
            onClick={() => setShowGlossary((g) => !g)}
          >
            Glossaire
          </button>
        </div>

        {pending && (
          <div className="dissertation-confirm" role="alert">
            <p>
              Remplacer votre définition par celle de <strong>{pending.terme}</strong> ?
            </p>
            <div className="dissertation-confirm-actions">
              <button type="button" className="dissertation-validate" onClick={() => apply(pending)}>
                Remplacer
              </button>
              <button type="button" className="dissertation-tool" onClick={() => setPending(null)}>
                Annuler
              </button>
            </div>
          </div>
        )}

        {showGlossary ? (
          <div className="dissertation-glossary-resizable">
            <div ref={boxRef} className="dissertation-glossary-box" style={{ flexBasis: glossaryH }}>
              <Glossary terms={results} selectedId={selectedId} onSelect={select} />
            </div>
            <div
              className="dissertation-grip"
              role="separator"
              aria-orientation="horizontal"
              aria-label="Redimensionner la liste du glossaire"
              aria-valuenow={glossaryH}
              aria-valuemin={GLOSSARY_MIN}
              tabIndex={0}
              onPointerDown={gripDown}
              onPointerMove={gripMove}
              onPointerUp={gripEnd}
              onPointerCancel={gripEnd}
              onKeyDown={gripKey}
            >
              <span />
            </div>
          </div>
        ) : (
          searching &&
          query.trim() &&
          (results.length === 0 ? (
            <p className="dissertation-tools-empty">Aucun terme trouvé.</p>
          ) : (
            <ul className="dissertation-results">
              {results.map((t) => (
                <li key={t.id}>
                  <button
                    type="button"
                    className={`dissertation-result${t.id === selectedId ? " is-selected" : ""}`}
                    onClick={() => select(t)}
                  >
                    <strong>{t.terme}</strong>
                    <span>{t.definition}</span>
                  </button>
                </li>
              ))}
            </ul>
          ))
        )}
      </div>
    </div>
  );
}
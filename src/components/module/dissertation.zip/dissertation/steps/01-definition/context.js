import { createContext, useContext } from "react";

/**
 * État de l'étape « Définition », partagé entre le nœud du sujet (SubjectText)
 * et la bulle (DefinitionProvider).
 *   definitions : { [motEnMinuscules]: [{ id, text, source? }, …] }  (source = id du terme du glossaire)
 *   openWord    : (texte, clé, élément, idDéfinition?) => void ; sans id = nouvelle définition
 *   editable    : false une fois l'étape validée (lecture seule, mais les mots gardent leurs poignées)
 */
export const DefinitionContext = createContext({ definitions: {}, openWord: null, editable: false });

export const useDefinitions = () => useContext(DefinitionContext);
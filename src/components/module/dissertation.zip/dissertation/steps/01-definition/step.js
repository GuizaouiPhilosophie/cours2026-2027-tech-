import Provider from "./DefinitionProvider";
import SubjectText from "./SubjectText";
import DefinitionNode from "./components/DefinitionNode";

export default {
  id: "definition",
  title: "Définition",
  description: "Cliquez sur un mot du sujet pour le définir.",
  order: 10,
  Provider,    // état + bulle de l'étape, enveloppe le canevas
  SubjectText, // rendu du sujet (mots cliquables)
  nodeTypes: { definition: DefinitionNode }, // nœuds ajoutés au canevas par l'étape
  // Renvoie un message d'erreur, ou null si l'étape peut être validée.
  // Seules les définitions de mots comptent (pas les nœuds créés depuis un concept associé).
  validate: ({ nodes }) =>
    nodes.filter((n) => n.type === "definition" && !n.data?.parent).length >= 2
      ? null
      : "Vous n'avez pas assez de définition pour passer à l'étape suivante.",
};
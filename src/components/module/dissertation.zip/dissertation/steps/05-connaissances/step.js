import Provider from "./KnowledgeProvider";
import KnowledgeNode from "./components/KnowledgeNode";
import KnowledgeEdge from "./components/KnowledgeEdge";

export default {
  id: "connaissances",
  title: "Connaissances",
  description: "Double-cliquez dans le vide pour noter ce que vous savez, puis reliez-le aux autres nœuds.",
  order: 50,
  Provider,
  nodeTypes: { connaissance: KnowledgeNode },
  edgeTypes: { connaissance: KnowledgeEdge },
  // Au moins une connaissance rédigée (les liens sont facultatifs).
  validate: ({ nodes }) =>
    nodes.some((n) => n.type === "connaissance")
      ? null
      : "Ajoutez au moins une connaissance pour passer à l'étape suivante.",
};

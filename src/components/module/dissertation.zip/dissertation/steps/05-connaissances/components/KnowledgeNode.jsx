import { Handle, Position } from "@xyflow/react";
import { useKnowledge } from "../context";
import { rectAnchor } from "../../03-contradictions/lib/anchor";

/**
 * Nœud « Connaissance » : ce que l'élève sait (auteur, notion, exemple…).
 * Un clic rouvre la bulle (texte et connexions). Les liens bleus sont flottants (KnowledgeEdge).
 */
export default function KnowledgeNode({ data }) {
  const { items, links, open } = useKnowledge();
  const text = items[data.kid]?.text ?? "";
  const self = `know-${data.kid}`;
  const count = Object.values(links).filter((l) => l.a === self || l.b === self).length;

  const go = (e) => open?.(data.kid, rectAnchor(e.currentTarget));
  return (
    <div
      className="dissertation-knownode"
      role={open ? "button" : undefined}
      tabIndex={open ? 0 : undefined}
      title={open ? "Modifier la connaissance" : undefined}
      onClick={open ? go : undefined}
      onKeyDown={open ? (e) => (e.key === "Enter" || e.key === " ") && go(e) : undefined}
    >
      {/* Une poignée par type suffit : le tracé des liens est calculé par KnowledgeEdge. */}
      <Handle type="target" position={Position.Top} isConnectable={false} className="dissertation-handle" />
      <Handle type="source" position={Position.Bottom} isConnectable={false} className="dissertation-handle" />
      <span className="dissertation-knownode-label">
        Connaissance{count > 0 ? ` · ${count} lien${count > 1 ? "s" : ""}` : ""}
      </span>
      <p>{text}</p>
    </div>
  );
}

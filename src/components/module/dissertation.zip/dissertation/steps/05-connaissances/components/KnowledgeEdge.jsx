import { BaseEdge, getStraightPath, useInternalNode } from "@xyflow/react";
import { useKnowledge } from "../context";
import { borderPoint } from "../../../lib/floatingEdge";

/** Lien bleu « flottant » entre une connaissance et un autre nœud. Un clic ouvre la bulle de la connaissance. */
export default function KnowledgeEdge({ id, source, target, data, style }) {
  const s = useInternalNode(source);
  const t = useInternalNode(target);
  const { open } = useKnowledge();
  if (!s?.measured?.width || !t?.measured?.width) return null;

  const a = borderPoint(s, t);
  const b = borderPoint(t, s);
  const [path] = getStraightPath({ sourceX: a.x, sourceY: a.y, targetX: b.x, targetY: b.y });

  return (
    <g
      className="dissertation-know-edge"
      onClick={(e) => open?.(data.kid, { x: e.clientX, top: e.clientY, bottom: e.clientY })}
    >
      <BaseEdge id={id} path={path} style={style} interactionWidth={28} />
    </g>
  );
}

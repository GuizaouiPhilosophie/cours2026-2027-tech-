import { useEffect, useMemo, useRef } from "react";
import useEscape from "../../../lib/useEscape";
import useSheetViewport from "../../../lib/useSheetViewport";

const WIDTH = 380;
const NARROW = 640;
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

/** Même placement que les autres bulles ; « feuille » en haut sur petit écran. */
function place(anchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (!anchor || vw < NARROW) return { sheet: true, style: {} };

  const left = clamp(anchor.x - WIDTH / 2, 8, vw - WIDTH - 8);
  const arrow = clamp(anchor.x - left, 24, WIDTH - 24);
  const room = vh - anchor.bottom;

  return room >= 360 || room >= anchor.top
    ? { side: "below", arrow, style: { left, top: anchor.bottom + 12, maxHeight: room - 20 } }
    : { side: "above", arrow, style: { left, bottom: vh - anchor.top + 12, maxHeight: anchor.top - 20 } };
}

/**
 * Bulle d'une connaissance : le texte (enregistré à chaque frappe), puis ses connexions,
 * chacune supprimable, et le bouton pour en créer une nouvelle.
 * `connections` : [{ lid, label, text? }]
 */
export default function KnowledgeBubble({
  anchor, text, exists, readOnly, connections, onChange, onLink, onUnlink, onDelete, onClose,
}) {
  const ref = useRef(null);
  const pos = useMemo(() => place(anchor), [anchor]);
  const sheet = useSheetViewport(pos.sheet); // petit écran : plein écran
  const canLink = !readOnly && text.trim() !== "";

  useEscape(onClose);

  useEffect(() => {
    const onDown = (e) => {
      if (ref.current?.contains(e.target)) return;
      if (e.target.closest?.(".dissertation-knownode")) return; // il (ré)ouvre la bulle
      onClose();
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className={`dissertation-bubble is-know ${pos.sheet ? "is-sheet" : `is-${pos.side}`}`}
      style={{ ...pos.style, ...sheet.style, "--arrow-x": `${pos.arrow ?? 0}px` }}
      role="dialog"
      aria-label="Connaissance"
    >
      <div className="dissertation-bubble-body">
        <div className="dissertation-bubble-head">
          <h2>Connaissance</h2>
          <button type="button" className="dissertation-close" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>

        <label className="dissertation-field dissertation-field-grow">
          <span>Ce que vous savez</span>
          <textarea
            autoFocus={!readOnly}
            rows={4}
            value={text}
            readOnly={readOnly}
            placeholder="Une notion, un auteur, un exemple, une référence de cours…"
            onChange={(e) => onChange(e.target.value)}
          />
        </label>

        <div className="dissertation-know-block">
          <span>Connexions ({connections.length})</span>
          {connections.length === 0 ? (
            <p className="dissertation-tools-empty">
              {readOnly ? "Aucune connexion." : "Reliez cette connaissance à un mot défini, une contradiction…"}
            </p>
          ) : (
            <ul className="dissertation-know-links">
              {connections.map((c) => (
                <li key={c.lid} className="dissertation-know-link">
                  <div>
                    <strong>{c.label}</strong>
                    {c.text?.trim() && <p>{c.text}</p>}
                  </div>
                  {!readOnly && (
                    <button
                      type="button"
                      className="dissertation-know-unlink"
                      onClick={() => onUnlink(c.lid)}
                      aria-label={`Supprimer le lien avec « ${c.label} »`}
                      title="Supprimer le lien"
                    >
                      ×
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>

        {!readOnly && (
          <div className="dissertation-know-actions">
            <button
              type="button"
              className="dissertation-know-btn is-link"
              onClick={onLink}
              disabled={!canLink}
              title={canLink ? undefined : "Écrivez d'abord votre connaissance"}
            >
              Relier à un nœud
            </button>
            {exists && (
              <button type="button" className="dissertation-know-btn is-delete" onClick={onDelete}>
                Supprimer
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

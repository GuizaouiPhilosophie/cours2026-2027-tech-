import { createContext, useContext } from "react";

/**
 * État de l'étape « Connaissances ».
 *   items : { [kid]: { id, text, position } }   (nœud React Flow : `know-<kid>`)
 *   links : { [lid]: { id, a, b } }             (a = nœud de connaissance, b = n'importe quel nœud reliable)
 *   open  : (kid, ancre) => void ; null tant que l'étape est verrouillée
 */
export const KnowledgeContext = createContext({ items: {}, links: {}, open: null });
export const useKnowledge = () => useContext(KnowledgeContext);

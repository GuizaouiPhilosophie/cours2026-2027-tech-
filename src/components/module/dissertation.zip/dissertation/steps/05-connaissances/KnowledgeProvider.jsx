import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import "./connaissances.css";
import { KnowledgeContext } from "./context";
import { useContradictions } from "../03-contradictions/context";
import { describe } from "../03-contradictions/lib/describe";
import { rectAnchor } from "../03-contradictions/lib/anchor";
import { DEF_Z_INDEX, EDGE_Z_INDEX } from "../01-definition/lib/placement";
import KnowledgeBubble from "./components/KnowledgeBubble";

const TYPE = "connaissance";
const knowId = (kid) => `know-${kid}`;
const LINKABLE = new Set(["subject", "definition", "reformulation", "contradiction", "problematique", TYPE]);
const STYLE = { stroke: "var(--knowledge)", strokeWidth: 2.5 };
const NODE_W = 240; // taille approximative d'un nœud de connaissance (flow units)
const NODE_H = 80;
const TAP_MS = 350; // délai max entre deux clics / touchers
const TAP_PX = 30; // écart max entre deux clics / touchers
const MOVE_PX = 6; // au-delà : glissement, pas un clic

let uid = 0;
const newId = () => `k${Date.now().toString(36)}${(uid++).toString(36)}`;

const nodeEl = (id) => document.querySelector(`.react-flow__node[data-id="${CSS.escape(id)}"]`);
const onEmptyPane = (t) =>
  !!t.closest?.(".react-flow__pane") &&
  !t.closest(".react-flow__node, .react-flow__edge, .react-flow__controls, .dissertation-bubble");

/**
 * Provider de l'étape : possède les connaissances et leurs liens bleus, et les reflète sur le canevas.
 *  - double-clic (ou double toucher) dans le vide : bulle d'une nouvelle connaissance ; le nœud
 *    apparaît à la première frappe, et disparaît si on ferme la bulle avec un texte vide ;
 *  - clic sur un nœud de connaissance ou sur un lien bleu : rouvre la bulle ;
 *  - « Relier à un nœud » dans la bulle, puis clic sur le nœud voulu : crée un lien
 *    (autant de liens que voulu, vers tout nœud de la carte).
 */
export default function KnowledgeProvider({ status, canvas, children }) {
  const { contradictions } = useContradictions();
  const [items, setItems] = useState({});
  const [links, setLinks] = useState({});
  const [bubble, setBubble] = useState(null); // { kid, anchor, position }
  const [picking, setPicking] = useState(null); // kid du nœud dont on crée un lien
  const enabled = status !== "locked";
  const editable = status === "current";
  const pickingId = editable ? picking : null;

  const itemsRef = useRef(items);
  itemsRef.current = items;
  const linksRef = useRef(links);
  linksRef.current = links;
  const bubbleRef = useRef(bubble);
  bubbleRef.current = bubble;

  /* ---------- Canevas ---------- */

  // Resynchronisé seulement quand des nœuds ou des liens apparaissent / disparaissent (pas à chaque frappe).
  const structure = useMemo(
    () => [Object.keys(items).join(","), Object.values(links).map((l) => `${l.id}|${l.a}|${l.b}`).join(";")].join("#"),
    [items, links]
  );

  useEffect(() => {
    const wanted = itemsRef.current;
    const edges = Object.values(linksRef.current).map((l) => ({
      id: `know:${l.id}`,
      type: TYPE,
      source: l.a,
      target: l.b,
      data: { lid: l.id, kid: l.a.slice(knowId("").length) },
      style: STYLE,
      zIndex: EDGE_Z_INDEX,
      deletable: false, // géré par la bulle
    }));

    canvas.setNodes((ns) => {
      const has = new Set(ns.map((n) => n.id));
      const kept = ns.filter((n) => n.type !== TYPE || wanted[n.data.kid]);
      const added = Object.values(wanted)
        .filter((k) => !has.has(knowId(k.id)))
        .map((k) => ({
          id: knowId(k.id),
          type: TYPE,
          zIndex: DEF_Z_INDEX,
          deletable: false,
          position: k.position,
          data: { kid: k.id },
        }));
      return added.length || kept.length !== ns.length ? [...kept, ...added] : ns;
    });

    canvas.setEdges((es) => {
      if (!edges.length && !es.some((e) => e.data?.lid)) return es;
      return [...es.filter((e) => !e.data?.lid), ...edges];
    });
  }, [structure, canvas]);

  // Surbrillance du nœud de départ pendant la liaison.
  useEffect(() => {
    const target = pickingId ? knowId(pickingId) : null;
    canvas.setNodes((ns) => {
      let changed = false;
      const out = ns.map((n) => {
        const rest = (n.className ?? "").split(/\s+/).filter((c) => c && c !== "is-know-source");
        const next = [...rest, n.id === target && "is-know-source"].filter(Boolean).join(" ");
        if (next === (n.className ?? "")) return n;
        changed = true;
        return { ...n, className: next || undefined };
      });
      return changed ? out : ns;
    });
  }, [pickingId, structure, canvas]);

  /* ---------- Bulle ---------- */

  const open = useCallback((kid, anchor) => {
    setPicking(null);
    setBubble({ kid, anchor });
  }, []);

  const remove = useCallback((kid) => {
    const id = knowId(kid);
    setItems((is) => {
      const out = { ...is };
      delete out[kid];
      return out;
    });
    setLinks((ls) => Object.fromEntries(Object.entries(ls).filter(([, l]) => l.a !== id && l.b !== id)));
    setBubble(null);
  }, []);

  // Fermer avec un texte vide supprime la connaissance (et ses liens).
  const close = useCallback(() => {
    const b = bubbleRef.current;
    const item = b && itemsRef.current[b.kid];
    if (item && !item.text.trim()) remove(b.kid);
    else setBubble(null);
  }, [remove]);

  const change = useCallback((kid, position, text) => {
    setItems((is) =>
      is[kid] ? { ...is, [kid]: { ...is[kid], text } } : { ...is, [kid]: { id: kid, text, position } }
    );
  }, []);

  const unlink = useCallback((lid) => {
    setLinks((ls) => {
      const out = { ...ls };
      delete out[lid];
      return out;
    });
  }, []);

  const startLink = useCallback((kid) => {
    setBubble(null);
    setPicking(kid);
  }, []);

  /* ---------- Double-clic dans le vide : nouvelle connaissance ---------- */

  useEffect(() => {
    if (!editable) return;
    let down = null;
    let last = null;
    const onDown = (e) => {
      down = onEmptyPane(e.target) ? { x: e.clientX, y: e.clientY } : null;
    };
    const onUp = (e) => {
      if (!down || picking) return;
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y) > MOVE_PX;
      down = null;
      if (moved) return;
      const now = Date.now();
      if (last && now - last.t < TAP_MS && Math.hypot(e.clientX - last.x, e.clientY - last.y) < TAP_PX) {
        last = null;
        const p = canvas.screenToFlowPosition({ x: e.clientX, y: e.clientY });
        setBubble({
          kid: newId(),
          anchor: { x: e.clientX, top: e.clientY, bottom: e.clientY },
          position: { x: p.x - NODE_W / 2, y: p.y - NODE_H / 2 },
        });
      } else {
        last = { x: e.clientX, y: e.clientY, t: now };
      }
    };
    window.addEventListener("pointerdown", onDown, true);
    window.addEventListener("pointerup", onUp, true);
    return () => {
      window.removeEventListener("pointerdown", onDown, true);
      window.removeEventListener("pointerup", onUp, true);
    };
  }, [editable, picking, canvas]);

  /* ---------- Liaison : clic sur le nœud à relier ---------- */

  useEffect(() => {
    if (!editable || !picking) return;
    const source = knowId(picking);
    let down = null;
    const reopen = () => {
      const el = nodeEl(source);
      setPicking(null);
      setBubble({ kid: picking, anchor: el ? rectAnchor(el) : null });
    };
    const onDown = (e) => {
      down = { x: e.clientX, y: e.clientY };
    };
    const onClick = (e) => {
      if (e.target.closest?.(".nodrag")) return;
      if (down && Math.hypot(e.clientX - down.x, e.clientY - down.y) > MOVE_PX) return; // glissement
      const el = e.target.closest?.(".react-flow__node");
      if (!el) {
        if (e.target.closest?.(".react-flow__pane")) setPicking(null); // clic dans le vide : annule
        return;
      }
      e.stopPropagation(); // le nœud cliqué ne doit pas ouvrir sa propre bulle
      const id = el.dataset.id;
      const node = canvas.getNodes().find((n) => n.id === id);
      if (!node || !LINKABLE.has(node.type) || id === source) return;
      const exists = Object.values(linksRef.current).some(
        (l) => (l.a === source && l.b === id) || (l.a === id && l.b === source)
      );
      if (!exists) {
        const lid = newId();
        setLinks((ls) => ({ ...ls, [lid]: { id: lid, a: source, b: id } }));
      }
      reopen();
    };
    const onKey = (e) => e.key === "Escape" && setPicking(null);
    window.addEventListener("pointerdown", onDown, true);
    window.addEventListener("click", onClick, true);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("pointerdown", onDown, true);
      window.removeEventListener("click", onClick, true);
      window.removeEventListener("keydown", onKey);
    };
  }, [editable, picking, canvas]);

  /* ---------- Rendu ---------- */

  /** Libellé et texte d'un nœud relié. */
  const label = (id, nodes) => {
    const n = nodes.find((x) => x.id === id);
    if (n?.type === TYPE) return { label: "Connaissance", text: items[n.data.kid]?.text };
    return describe(id, nodes, contradictions);
  };

  const value = useMemo(
    () => ({ items, links, open: enabled && !pickingId ? open : null }),
    [items, links, enabled, pickingId, open]
  );

  const current = bubble;
  let connections = [];
  if (enabled && current) {
    const self = knowId(current.kid);
    const nodes = canvas.getNodes();
    connections = Object.values(links)
      .filter((l) => l.a === self || l.b === self)
      .map((l) => ({ lid: l.id, ...label(l.a === self ? l.b : l.a, nodes) }));
  }

  return (
    <KnowledgeContext.Provider value={value}>
      {children}

      {editable && (
        <div className="dissertation-knowbar">
          <p className="dissertation-knowhint">
            {pickingId
              ? "Cliquez sur le nœud à relier (Échap ou clic dans le vide pour annuler)."
              : "Double-cliquez dans le vide pour ajouter une connaissance."}
          </p>
        </div>
      )}

      {enabled && current && (
        <KnowledgeBubble
          key={current.kid}
          anchor={current.anchor}
          text={items[current.kid]?.text ?? ""}
          exists={!!items[current.kid]}
          readOnly={!editable}
          connections={connections}
          onChange={(text) => change(current.kid, current.position, text)}
          onLink={() => startLink(current.kid)}
          onUnlink={unlink}
          onDelete={() => remove(current.kid)}
          onClose={close}
        />
      )}
    </KnowledgeContext.Provider>
  );
}

import { useState } from "react";
import steps from "./stepRegistry";

/**
 * Menu du bas « Parcours de rédaction » : un bouton hamburger ouvre une
 * frise horizontale (gauche → droite) des étapes. L'étape courante affiche
 * sa description, ses outils et le bouton de validation. Les suivantes
 * sont verrouillées.
 */
export default function StepPanel({ validated, onValidate, onOpenTool, error }) {
  const [open, setOpen] = useState(false);
  const currentIndex = steps.findIndex((s) => !validated.includes(s.id));
  const allDone = currentIndex === -1;
  const current = allDone ? null : steps[currentIndex];

  return (
    <div className="dissertation-dock">
      <button
        type="button"
        className={`dissertation-burger${open ? " is-open" : ""}`}
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls="dissertation-menu"
        aria-label={open ? "Fermer le parcours de rédaction" : "Ouvrir le parcours de rédaction"}
      >
        <span className="dissertation-burger-icon" aria-hidden="true">
          <span />
          <span />
          <span />
        </span>
        {current && (
          <span className="dissertation-burger-label" aria-hidden={open}>
            <span className="dissertation-burger-label-inner">{current.title}</span>
          </span>
        )}
      </button>

      <div className={`dissertation-drawer${open ? " is-open" : ""}`}>
        <nav id="dissertation-menu" className="dissertation-panel" aria-label="Parcours de rédaction">
          <div className="dissertation-panel-scroll">
          <h2 className="dissertation-panel-title">Parcours de rédaction</h2>

          <ol className="dissertation-steps">
            {steps.map((step, i) => {
              const done = validated.includes(step.id);
              const isCurrent = i === currentIndex;
              const state = done ? "done" : isCurrent ? "current" : "locked";

              return (
                <li
                  key={step.id}
                  className={`dissertation-step is-${state}`}
                  aria-current={isCurrent ? "step" : undefined}
                >
                  <span className="dissertation-step-badge" aria-hidden="true">
                    {done ? "✓" : i + 1}
                  </span>
                  <span className="dissertation-step-title">{step.title}</span>
                </li>
              );
            })}
          </ol>

          {current && (
            <div className="dissertation-step-detail">

              {error && (
                <p className="dissertation-step-error" role="alert">
                  {error}
                </p>
              )}

              <button
                type="button"
                className="dissertation-validate"
                onClick={() => onValidate(current.id)}
              >
                Valider l’étape
              </button>
            </div>
          )}

          {allDone && steps.length > 0 && (
            <p className="dissertation-panel-done">Toutes les étapes sont validées.</p>
          )}
          {steps.length === 0 && <p className="dissertation-tools-empty">Aucune étape détectée.</p>}
          </div>
        </nav>
      </div>
    </div>
  );
}